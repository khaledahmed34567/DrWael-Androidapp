package com.drwael.app

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONObject
import org.json.JSONTokener

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var webHolder: FrameLayout
    private lateinit var statusFill: View
    private lateinit var navFill: View
    private lateinit var fullscreenHolder: FrameLayout
    private lateinit var lockView: View
    private lateinit var lockTitle: TextView
    private lateinit var lockMsg: TextView
    private lateinit var lockBtn: Button
    private lateinit var lockBtn2: Button
    private lateinit var webView: WebView
    private lateinit var loader: WebViewAssetLoader

    private val handler = Handler(Looper.getMainLooper())
    private val bridge = Bridge(this)

    private var locked = true
    private var needEnroll = false
    private var bioBusy = false
    private var bgAt = 0L
    internal var skipLock = false

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val res = WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data)
            fileCb?.onReceiveValue(res)
            fileCb = null
        }

    private val notifLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) toast(R.string.notif_perm_denied)
        }

    // ------------------------------------------------------------------ دورة الحياة

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // منع لقطة الشاشة وتسجيل الشاشة ومعاينة التطبيقات الأخيرة
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(false)

        root = findViewById(R.id.root)
        webHolder = findViewById(R.id.webHolder)
        statusFill = findViewById(R.id.statusFill)
        navFill = findViewById(R.id.navFill)
        fullscreenHolder = findViewById(R.id.fullscreenHolder)
        lockView = findViewById(R.id.lockView)
        lockTitle = findViewById(R.id.lockTitle)
        lockMsg = findViewById(R.id.lockMsg)
        lockBtn = findViewById(R.id.lockBtn)
        lockBtn2 = findViewById(R.id.lockBtn2)

        setupInsets()
        setupLockUi()
        buildWebView()
        showLock()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customView != null) { hideCustomView(); return }
                if (locked) { moveTaskToBack(true); return }
                webView.evaluateJavascript(BACK_JS) { r ->
                    if (r != "true") moveTaskToBack(true)
                }
            }
        })

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            lockTitle.setText(R.string.app_name)
            lockMsg.setText(R.string.webview_old)
            lockBtn.visibility = View.GONE
            return
        }
        webView.loadUrl(Cfg.START_URL)
    }

    override fun onStart() {
        super.onStart()
        val away = SystemClock.elapsedRealtime() - bgAt
        if (!locked && bgAt != 0L && !skipLock && away > Cfg.LOCK_GRACE_MS) {
            locked = true
            showLock()
        }
        skipLock = false
        if (locked && WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) promptUnlock()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
        if (!locked) handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        webView.onPause()
        super.onPause()
    }

    override fun onStop() {
        super.onStop()
        bgAt = SystemClock.elapsedRealtime()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            webHolder.removeAllViews()
            webView.stopLoading()
            webView.destroy()
        } catch (e: Exception) {
            // تجاهل
        }
        super.onDestroy()
    }

    // ------------------------------------------------------------------ الحواف وألوان الأشرطة

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val imeUp = ime.bottom > bars.bottom
            val bottom = if (imeUp) ime.bottom else bars.bottom

            statusFill.layoutParams = statusFill.layoutParams.apply { height = bars.top }
            navFill.layoutParams = navFill.layoutParams.apply { height = if (imeUp) 0 else bars.bottom }
            webHolder.setPadding(bars.left, bars.top, bars.right, bottom)
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun applyBars(top: Int, bottom: Int) {
        statusFill.setBackgroundColor(top)
        navFill.setBackgroundColor(bottom)
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.isAppearanceLightStatusBars = ColorUtils.calculateLuminance(top) > 0.6
        c.isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(bottom) > 0.6
    }

    /** يقرأ لون أعلى وأسفل الصفحة الحالي ليتطابق شريط الحالة مع الهيدر والشريط السفلي */
    private val poll = object : Runnable {
        override fun run() {
            if (!locked && customView == null) {
                webView.evaluateJavascript(COLORS_JS) { v -> parseColors(v) }
            }
            handler.postDelayed(this, 800)
        }
    }

    private fun parseColors(v: String?) {
        if (v == null || v == "null") return
        try {
            val s = JSONTokener(v).nextValue() as? String ?: return
            if (s.isBlank()) return
            val j = JSONObject(s)
            val t = j.optJSONArray("t")
            val b = j.optJSONArray("b")
            if (t == null || b == null) return
            val top = Color.rgb(t.optDouble(0).toInt(), t.optDouble(1).toInt(), t.optDouble(2).toInt())
            val bot = Color.rgb(b.optDouble(0).toInt(), b.optDouble(1).toInt(), b.optDouble(2).toInt())
            applyBars(top, bot)
        } catch (e: Exception) {
            // تجاهل
        }
    }

    // ------------------------------------------------------------------ القفل بالبصمة

    private fun authenticators() =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    private fun canAuth() =
        BiometricManager.from(this).canAuthenticate(authenticators()) == BiometricManager.BIOMETRIC_SUCCESS

    private fun setupLockUi() {
        lockBtn.setOnClickListener {
            if (needEnroll) openSecuritySettings() else promptUnlock()
        }
        lockBtn2.setOnClickListener { promptUnlock() }
    }

    private fun showLock() {
        lockView.visibility = View.VISIBLE
        webView.visibility = View.INVISIBLE
        applyBars(ContextCompat.getColor(this, R.color.navy2), ContextCompat.getColor(this, R.color.navy))
    }

    private fun unlock() {
        locked = false
        needEnroll = false
        lockView.visibility = View.GONE
        webView.visibility = View.VISIBLE
        webView.requestFocus()
        handler.removeCallbacks(poll)
        handler.post(poll)
        askNotificationPermissionOnce()
    }

    private fun promptUnlock() {
        if (!locked) return
        if (!canAuth()) {
            needEnroll = true
            lockTitle.setText(R.string.enroll_title)
            lockMsg.setText(R.string.enroll_msg)
            lockBtn.setText(R.string.enroll_btn)
            lockBtn2.visibility = View.VISIBLE
            return
        }
        needEnroll = false
        lockTitle.setText(R.string.lock_title)
        lockMsg.setText(R.string.lock_msg)
        lockBtn.setText(R.string.lock_btn)
        lockBtn2.visibility = View.GONE
        biometric(getString(R.string.lock_prompt_title), getString(R.string.lock_prompt_sub)) { ok ->
            if (ok) unlock()
        }
    }

    private fun openSecuritySettings() {
        skipLock = true
        val i = if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_BIOMETRIC_ENROLL)
                .putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, authenticators())
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        }
        try {
            startActivity(i)
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { /* تجاهل */ }
        }
    }

    private fun biometric(title: String, sub: String, cb: (Boolean) -> Unit) {
        if (bioBusy) { cb(false); return }
        if (!canAuth()) { cb(false); return }
        bioBusy = true
        val prompt = BiometricPrompt(
            this, ContextCompat.getMainExecutor(this),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    bioBusy = false
                    cb(true)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    bioBusy = false
                    cb(false)
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle(sub)
            .setAllowedAuthenticators(authenticators())
            .setConfirmationRequired(false)
            .build()
        prompt.authenticate(info)
    }

    /** يُستدعى من الجسر قبل عمليات الدفع وأي عملية حساسة */
    fun requestBiometric(why: String, cb: (Boolean) -> Unit) {
        if (locked) { cb(false); return }
        val pay = why == "pay"
        biometric(
            getString(if (pay) R.string.pay_prompt_title else R.string.auth_prompt_title),
            getString(if (pay) R.string.pay_prompt_sub else R.string.lock_prompt_sub),
            cb
        )
    }

    private fun askNotificationPermissionOnce() {
        if (Build.VERSION.SDK_INT < 33 || Notifs.hasPermission(this)) return
        val p = Store.plain(this)
        if (p.getBoolean("notif_asked", false)) return
        p.edit().putBoolean("notif_asked", true).apply()
        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    fun toast(res: Int) {
        runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show() }
    }

    // ------------------------------------------------------------------ WebView

    private fun buildWebView() {
        loader = WebViewAssetLoader.Builder()
            .setDomain(BuildConfig.APP_HOST)
            .setHttpAllowed(false)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#16235A"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            isLongClickable = false
            setOnLongClickListener { true }
        }
        webHolder.addView(webView)

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        @Suppress("DEPRECATION")
        s.databaseEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        s.textZoom = 100
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.displayZoomControls = false
        s.setGeolocationEnabled(false)
        s.cacheMode = WebSettings.LOAD_DEFAULT
        s.userAgentString = s.userAgentString + " DrWaelApp/" + BuildConfig.VERSION_NAME
        if (Build.VERSION.SDK_INT >= 26) s.safeBrowsingEnabled = true
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, false)
        }

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.setDownloadListener { url, _, _, _, _ ->
            openExternal(Uri.parse(url))
        }

        // الجسر: يظهر في الصفحة كـ window.DWNative (postMessage + onmessage) وللأصل المحدد فقط
        if (WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(
                webView, "DWNative", setOf(Cfg.ORIGIN)
            ) { _, message, sourceOrigin, isMainFrame, reply ->
                val okOrigin = sourceOrigin.scheme == "https" && sourceOrigin.host == BuildConfig.APP_HOST
                val data = message.data
                if (isMainFrame && okOrigin && data != null) {
                    bridge.handle(data) { json -> runOnUiThread { reply.postMessage(json) } }
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val own = u.scheme == "https" && u.host == BuildConfig.APP_HOST &&
                    (u.path ?: "").startsWith("/assets/")
                if (own) return false
                if (!request.isForMainFrame) return false
                openExternal(u)
                return true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                handler.post { recreate() }
                return true
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                wv: WebView, cb: ValueCallback<Array<Uri>>, params: FileChooserParams
            ): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                skipLock = true
                return try {
                    fileLauncher.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCb = null
                    false
                }
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                fullscreenHolder.addView(
                    view, FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                fullscreenHolder.visibility = View.VISIBLE
                val c = WindowInsetsControllerCompat(window, window.decorView)
                c.hide(WindowInsetsCompat.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }

            override fun onHideCustomView() {
                hideCustomView()
            }

            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                // window.open / target=_blank: نفتح الرابط في المتصفح الخارجي بدل ما يستبدل صفحة التطبيق
                val tmp = WebView(view.context)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        openExternal(r.url)
                        handler.post { v.destroy() }
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }

            override fun getDefaultVideoPoster(): Bitmap? =
                Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)

            override fun onPermissionRequest(request: PermissionRequest) {
                request.deny()
            }
        }
    }

    private fun hideCustomView() {
        val v = customView ?: return
        fullscreenHolder.removeView(v)
        fullscreenHolder.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    private fun openExternal(u: Uri) {
        val sc = u.scheme?.lowercase()
        if (sc != "http" && sc != "https" && sc != "mailto" && sc != "tel") return
        skipLock = true
        try {
            startActivity(Intent(Intent.ACTION_VIEW, u).addCategory(Intent.CATEGORY_BROWSABLE))
        } catch (e: Exception) {
            // لا يوجد تطبيق يفتح الرابط
        }
    }

    companion object {
        /** زر الرجوع: يغلق أي نافذة مفتوحة في الصفحة، وإلا يُنزل التطبيق للخلفية */
        private const val BACK_JS = """(function(){
var q=['#modal2 .x','#modal .x','#gx','#sb'];
for(var i=0;i<q.length;i++){var e=document.querySelector(q[i]);
if(e&&e.getClientRects().length>0){e.click();return true}}
return false})()"""

        /** لون أعلى الصفحة وأسفلها (يبحث عن أول عنصر له خلفية/تدرج) */
        private const val COLORS_JS = """(function(){try{
function pc(s){var m=/rgba?\(([^)]+)\)/g,a=[],x;while((x=m.exec(s||''))){var p=x[1].split(',').map(parseFloat);if(p.length>3&&p[3]<0.5)continue;a.push([p[0],p[1],p[2]])}return a}
function col(y,last){var el=document.elementFromPoint(Math.floor(innerWidth/2),y);
while(el){var cs=getComputedStyle(el);var g=pc(cs.backgroundImage);
if(g.length)return last?g[g.length-1]:g[0];
var b=pc(cs.backgroundColor);if(b.length)return b[0];el=el.parentElement}
return [241,241,244]}
return JSON.stringify({t:col(2,false),b:col(innerHeight-2,true)})}catch(e){return ''}})()"""
    }
}
