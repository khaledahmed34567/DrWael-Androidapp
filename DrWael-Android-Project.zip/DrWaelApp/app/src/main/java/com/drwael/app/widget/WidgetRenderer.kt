package com.drwael.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.widget.RemoteViews
import com.drwael.app.MainActivity
import com.drwael.app.R
import com.drwael.app.Store
import java.util.Calendar
import java.util.Locale

object WidgetRenderer {
    private val ORDER = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")

    private fun pName(c: Context, k: String): String = c.getString(
        when (k) {
            "Fajr" -> R.string.p_fajr
            "Dhuhr" -> R.string.p_dhuhr
            "Asr" -> R.string.p_asr
            "Maghrib" -> R.string.p_maghrib
            else -> R.string.p_isha
        }
    )

    private fun mins(t: String): Int {
        val p = t.take(5).split(":")
        return p[0].toInt() * 60 + p[1].toInt()
    }

    /** الصلاة القادمة + عدد الدقائق المتبقية + وقت حدوثها بالمللي ثانية */
    data class Next(val key: String, val inMin: Int, val atMs: Long)

    fun next(s: Snap): Next? {
        return try {
            val now = Calendar.getInstance()
            val cur = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val k = ORDER.firstOrNull { mins(s.timings[it] ?: return null) > cur }
            if (k != null) {
                val m = mins(s.timings[k]!!)
                val at = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                Next(k, m - cur, at)
            } else {
                val m = mins(s.timings["Fajr"] ?: return null)
                val at = Calendar.getInstance().apply {
                    add(Calendar.DAY_OF_YEAR, 1)
                    set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
                    set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                Next("Fajr", (24 * 60 - cur) + m, at)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun background(w: Int, h: Int, density: Float, th: WTheme): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val r = 22f * density
        val clip = Path().apply { addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW) }
        cv.clipPath(clip)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), th.h1, th.h2, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        fun glow(cx: Float, cy: Float, rad: Float, col: Int) {
            val g = Paint(Paint.ANTI_ALIAS_FLAG)
            val transparent = Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))
            g.shader = RadialGradient(cx, cy, rad, col, transparent, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, rad, g)
        }
        val big = maxOf(w, h).toFloat()
        glow(w * 0.12f, h * 0.05f, big * 0.55f, th.ga)
        glow(w * 0.95f, h * 0.15f, big * 0.45f, th.gb)
        glow(w * 0.7f, h * 1.05f, big * 0.5f, th.gc)
        val b = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.2f * density; color = Color.argb(46, 255, 255, 255)
        }
        cv.drawRoundRect(RectF(1f, 1f, w - 1f, h - 1f), r, r, b)
        return bmp
    }

    fun renderAll(c: Context) {
        val mgr = AppWidgetManager.getInstance(c)
        val ids = mgr.getAppWidgetIds(ComponentName(c, PrayerWidget::class.java))
        if (ids.isEmpty()) return
        for (id in ids) render(c, mgr, id)
    }

    fun render(c: Context, mgr: AppWidgetManager, id: Int) {
        val density = c.resources.displayMetrics.density
        val opts = mgr.getAppWidgetOptions(id)
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250).coerceAtLeast(120)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110).coerceAtLeast(80)
        var w = (wDp * density).toInt()
        var h = (hDp * density).toInt()
        val maxPx = 900_000
        if (w * h > maxPx) {
            val k = Math.sqrt(maxPx.toDouble() / (w * h)).toFloat()
            w = (w * k).toInt(); h = (h * k).toInt()
        }
        val cityKey = Store.city(c)
        val city = Cities.byKey(cityKey)
        val th = WidgetThemes.get(Store.widgetTheme(c))
        val ar = Locale.getDefault().language == "ar"
        val snap = WidgetData.cached(c, cityKey)

        val rv = RemoteViews(c.packageName, R.layout.widget_prayer)
        rv.setImageViewBitmap(R.id.w_bg, background(w, h, density, th))
        rv.setTextViewText(R.id.w_city, (if (ar) "د. وائل · " else "Dr. Wael · ") + (if (ar) city.ar else city.en))
        rv.setTextColor(R.id.w_city, th.gold)
        rv.setTextColor(R.id.w_next_time, th.gold)

        val pn = intArrayOf(R.id.w_pn1, R.id.w_pn2, R.id.w_pn3, R.id.w_pn4, R.id.w_pn5)
        val pt = intArrayOf(R.id.w_pt1, R.id.w_pt2, R.id.w_pt3, R.id.w_pt4, R.id.w_pt5)

        if (snap == null || snap.timings.isEmpty()) {
            rv.setTextViewText(R.id.w_next_name, c.getString(R.string.widget_loading))
            rv.setTextViewText(R.id.w_next_time, "")
            rv.setTextViewText(R.id.w_next_in, "")
            rv.setTextViewText(R.id.w_date, "")
            rv.setTextViewText(R.id.w_weather, "")
            for (i in 0..4) {
                rv.setTextViewText(pn[i], pName(c, ORDER[i]))
                rv.setTextViewText(pt[i], "--:--")
            }
        } else {
            val nx = next(snap)
            rv.setTextViewText(R.id.w_date, snap.hijri)
            if (nx != null) {
                rv.setTextViewText(R.id.w_next_name, pName(c, nx.key))
                rv.setTextViewText(R.id.w_next_time, snap.timings[nx.key] ?: "")
                val hh = nx.inMin / 60
                val mm = nx.inMin % 60
                val left = (if (hh > 0) "$hh${c.getString(R.string.widget_h)} " else "") + "$mm${c.getString(R.string.widget_m)}"
                rv.setTextViewText(R.id.w_next_in, c.getString(R.string.widget_in) + " " + left)
            }
            for (i in 0..4) {
                val k = ORDER[i]
                val hot = nx?.key == k
                rv.setTextViewText(pn[i], pName(c, k))
                rv.setTextViewText(pt[i], snap.timings[k] ?: "--:--")
                rv.setTextColor(pt[i], if (hot) th.gold else Color.WHITE)
                rv.setTextColor(pn[i], if (hot) th.gold else Color.argb(191, 255, 255, 255))
            }
            val parts = ArrayList<String>()
            if (snap.temp != null) parts.add("${snap.temp}°")
            if (snap.code != null) parts.add(WeatherCodes.text(snap.code, ar))
            if (snap.hi != null && snap.lo != null) {
                parts.add("${c.getString(R.string.widget_high)} ${snap.hi}° / ${c.getString(R.string.widget_low)} ${snap.lo}°")
            }
            rv.setTextViewText(R.id.w_weather, parts.joinToString("  ·  "))
            if (nx != null) PrayerWidget.scheduleTick(c, nx.atMs + 1500)
        }

        val open = Intent(c, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        rv.setOnClickPendingIntent(
            R.id.w_root,
            PendingIntent.getActivity(c, 4242, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        )
        mgr.updateAppWidget(id, rv)
    }
}
