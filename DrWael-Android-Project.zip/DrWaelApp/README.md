# تطبيق د. وائل (Dr. Wael) — مشروع أندرويد

التطبيق بيشغّل ملف `index.html` **بدون أي تعديل** (موجود في `app/src/main/assets/index.html`) جوه WebView،
وبيوفّر الجسر `DWNative` اللي الصفحة مبنية عليه: تسجيل جوجل، البصمة، الإشعارات، التذكيرات، حفظ الملفات، تغيير الأيقونة، والويدجت.

## البصمة (أضفها في Firebase)
- Package name: `com.drwael.app`
- SHA-1: `D8:90:13:1A:FC:41:EE:CA:B5:97:B5:4A:13:2D:52:3B:B7:DC:91:B9`
- SHA-256: `39:42:35:15:BA:8D:B8:EE:AF:3F:AA:C7:CC:D9:44:2B:E1:33:1E:FE:46:73:BF:9C:76:27:FB:AD:27:CE:F5:85`

## خطوات تفعيل تسجيل جوجل (مهمة)
1. Firebase Console > Project settings > Add app > Android، اكتب `com.drwael.app`.
2. أضف SHA-1 و SHA-256 فوق.
3. نزّل `google-services.json` الجديد واستبدل `app/google-services.json` (الموجود حاليًا قالب بدون OAuth clients).
4. تأكد إن Google مفعّل في Authentication > Sign-in method.
5. ارفع على GitHub، والـ APK هيتبني تلقائيًا.

بدل الخطوة 3 ممكن تضيف Variable في GitHub باسم `WEB_CLIENT_ID` (Web client ID من Google Cloud).

## البناء على GitHub
ملف البناء: `.github/workflows/build.yml`. بعد أي push روح Actions > آخر Run > Artifacts > `DrWael-APK`.
محليًا: `gradle :app:assembleRelease` (Gradle 8.9 + JDK 17 + Android SDK 35).

## اللي متضمّن
- منع لقطة الشاشة وتسجيل الشاشة ومعاينة الأخيرة (`FLAG_SECURE`).
- قفل إجباري بالبصمة/الوجه/قفل الشاشة عند الفتح (سماح 30 ثانية بعد الخروج) وقبل أي دفع.
- تسجيل الدخول محفوظ (تخزين الصفحة ثابت) والجلسة الخلفية مشفّرة.
- هيدر وشريط سفلي: ألوان شريط الحالة بتتبع تصميم الصفحة تلقائيًا ومعالجة الحواف والكيبورد.
- إشعارات في الخلفية كل 15 دقيقة، تذكيرات دقيقة، وتذكير مذاكرة يومي.
- ويدجت مواقيت الصلاة والطقس بثيمات الصفحة.
- 7 أيقونات للتطبيق قابلة للتبديل من الإعدادات.

## ملاحظات أمان
- ملف التوقيع `app/keystore/drwael-release.jks` وكلمته داخل المشروع عشان البصمة تفضل ثابتة. **استخدم Repo خاص (Private)**، أو بدّله بمفتاحك وحدّث البصمة.
- دومين الصفحة داخل التطبيق هو authDomain بتاع Firebase (`appHost` في `app/build.gradle.kts`) فمش محتاج تضيف دومين جديد.
- الأيقونات الستة غير الافتراضية مصدرها 72px مكبّرة؛ استبدل ملفات `ic_fg_*.png` لو عندك نسخ أعلى جودة.
