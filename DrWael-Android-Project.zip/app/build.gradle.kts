import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

// ---- إعدادات قابلة للتغيير (من gradle.properties أو -P أو متغيرات البيئة) ----
fun cfg(name: String, def: String): String {
    val envName = name.replace(Regex("([a-z0-9])([A-Z])"), "\$1_\$2").uppercase()
    return (project.findProperty(name) as String?)?.takeIf { it.isNotBlank() }
        ?: System.getenv(envName)?.takeIf { it.isNotBlank() }
        ?: def
}

// دومين الصفحة داخل التطبيق. الافتراضي = authDomain الخاص بـ Firebase فيكون مصرّحًا تلقائيًا
// ولا تحتاج إضافة أي دومين في Firebase Authentication > Authorized domains.
val appHost = cfg("appHost", "khuwaylid-abc23.firebaseapp.com")
// Web client ID (اختياري): لو تركته فارغًا يُقرأ تلقائيًا من google-services.json (default_web_client_id)
val webClientId = cfg("webClientId", "")
val firebaseProjectId = cfg("firebaseProjectId", "khuwaylid-abc23")
// مستودع GitHub الذي تُنشر فيه الإصدارات (Releases) للتحديث داخل التطبيق
val firebaseApiKey = cfg("firebaseApiKey", "AIzaSyBG_xwaCuYe4rQug0CKxi9B-GqN9mK-m4M")
val serverBase = cfg("serverBase", "https://ais-dev-ib6zqhmdkwmky5rvtuie7u-262382091441.europe-west2.run.app")

val ksProps = Properties().apply {
    val f = rootProject.file("app/keystore/keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    namespace = "com.drwael.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.drwael.app"
        minSdk = 24
        targetSdk = 35
        versionCode = (project.findProperty("versionCode") as String?)?.toInt() ?: 1
        versionName = (project.findProperty("versionName") as String?) ?: "1.0.0"

        buildConfigField("String", "APP_HOST", "\"$appHost\"")
        buildConfigField("String", "WEB_CLIENT_ID", "\"$webClientId\"")
        buildConfigField("String", "FIREBASE_PROJECT_ID", "\"$firebaseProjectId\"")
        buildConfigField("String", "FIREBASE_API_KEY", "\"$firebaseApiKey\"")
        buildConfigField("String", "SERVER_BASE", "\"$serverBase\"")
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("app/keystore/" + (ksProps.getProperty("storeFile") ?: "drwael-release.jks"))
            storePassword = System.getenv("KEYSTORE_PASSWORD")?.takeIf { it.isNotBlank() } ?: ksProps.getProperty("storePassword") ?: ""
            keyAlias = ksProps.getProperty("keyAlias") ?: "drwael"
            keyPassword = System.getenv("KEYSTORE_PASSWORD")?.takeIf { it.isNotBlank() } ?: ksProps.getProperty("keyPassword") ?: ""
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            // نفس التوقيع حتى تبقى البصمة (SHA-1) ثابتة في كل النسخ
            signingConfig = signingConfigs.getByName("release")
            applicationIdSuffix = ""
        }
    }

    buildFeatures {
        buildConfig = true
        viewBinding = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES")
    }
    androidResources {
        // لا نضغط ملف الصفحة حتى يبقى كما هو بالضبط
        noCompress += "html"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("androidx.webkit:webkit:1.11.0")
    implementation("androidx.biometric:biometric:1.1.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.credentials:credentials:1.3.0")
    implementation("androidx.credentials:credentials-play-services-auth:1.3.0")
    implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
