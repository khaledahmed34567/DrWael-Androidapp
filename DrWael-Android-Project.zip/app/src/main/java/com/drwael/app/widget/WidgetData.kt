package com.drwael.app.widget

import android.content.Context
import com.drwael.app.Store
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** بيانات الويدجت: مواقيت الصلاة (Aladhan) والطقس (Open-Meteo) — نفس المصادر المستخدمة في الصفحة */
data class Snap(
    val city: String,
    val day: String,
    val timings: Map<String, String>,
    val hijri: String,
    val temp: Int?,
    val code: Int?,
    val hi: Int?,
    val lo: Int?,
    val fetchedAt: Long
)

object WidgetData {
    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun get(url: String): String {
        val u = URL(url).openConnection() as HttpURLConnection
        u.connectTimeout = 15000
        u.readTimeout = 20000
        u.setRequestProperty("Accept", "application/json")
        if (u.responseCode !in 200..299) throw IllegalStateException("HTTP ${u.responseCode}")
        return u.inputStream.bufferedReader().use { it.readText() }
    }

    fun cached(c: Context, cityKey: String): Snap? {
        val s = Store.plain(c).getString("wd_$cityKey", null) ?: return null
        return try {
            val j = JSONObject(s)
            val t = j.getJSONObject("t")
            val map = HashMap<String, String>()
            t.keys().forEach { map[it] = t.getString(it) }
            Snap(
                cityKey, j.getString("day"), map, j.optString("h", ""),
                if (j.has("temp")) j.getInt("temp") else null,
                if (j.has("code")) j.getInt("code") else null,
                if (j.has("hi")) j.getInt("hi") else null,
                if (j.has("lo")) j.getInt("lo") else null,
                j.optLong("at", 0L)
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun save(c: Context, s: Snap) {
        val j = JSONObject()
            .put("day", s.day).put("h", s.hijri).put("at", s.fetchedAt)
            .put("t", JSONObject(s.timings as Map<*, *>))
        s.temp?.let { j.put("temp", it) }
        s.code?.let { j.put("code", it) }
        s.hi?.let { j.put("hi", it) }
        s.lo?.let { j.put("lo", it) }
        Store.plain(c).edit().putString("wd_${s.city}", j.toString()).apply()
    }

    /** يجلب البيانات من الإنترنت ويخزنها. يرمي استثناء عند فشل المواقيت. */
    fun refresh(c: Context, cityKey: String): Snap {
        val city = Cities.byKey(cityKey)
        val pr = JSONObject(
            get(
                "https://api.aladhan.com/v1/timingsByCity?city=" +
                    URLEncoder.encode(city.key, "UTF-8") + "&country=Egypt&method=5"
            )
        ).getJSONObject("data")
        val tm = pr.getJSONObject("timings")
        val timings = HashMap<String, String>()
        for (k in listOf("Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha")) {
            timings[k] = tm.getString(k).take(5)
        }
        val h = pr.optJSONObject("date")?.optJSONObject("hijri")
        val hijri = if (h != null) {
            val m = h.optJSONObject("month")
            val ar = Locale.getDefault().language == "ar"
            h.optString("day") + " " + (if (ar) m?.optString("ar") else m?.optString("en")) + " " + h.optString("year")
        } else ""

        var temp: Int? = null; var code: Int? = null; var hi: Int? = null; var lo: Int? = null
        try {
            val w = JSONObject(
                get(
                    "https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}" +
                        "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                        "&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1"
                )
            )
            val cur = w.getJSONObject("current")
            temp = Math.round(cur.getDouble("temperature_2m")).toInt()
            code = cur.getInt("weather_code")
            val d = w.getJSONObject("daily")
            hi = Math.round(d.getJSONArray("temperature_2m_max").getDouble(0)).toInt()
            lo = Math.round(d.getJSONArray("temperature_2m_min").getDouble(0)).toInt()
        } catch (e: Exception) {
            // الطقس اختياري؛ نكمل بالمواقيت
        }
        val snap = Snap(city.key, today(), timings, hijri, temp, code, hi, lo, System.currentTimeMillis())
        save(c, snap)
        return snap
    }
}
