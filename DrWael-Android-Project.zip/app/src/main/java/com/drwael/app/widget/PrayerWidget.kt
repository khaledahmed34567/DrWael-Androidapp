package com.drwael.app.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.drwael.app.Cfg
import java.util.concurrent.TimeUnit

/** ويدجت الشاشة الرئيسية: مواقيت الصلاة والطقس بنفس ثيم التطبيق */
class PrayerWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) WidgetRenderer.render(context, appWidgetManager, id)
        enqueueOnce(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        WidgetRenderer.render(context, appWidgetManager, appWidgetId)
    }

    override fun onEnabled(context: Context) {
        val req = PeriodicWorkRequestBuilder<WidgetWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(Cfg.WIDGET_WORK_PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        enqueueOnce(context)
    }

    override fun onDisabled(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(Cfg.WIDGET_WORK_PERIODIC)
        cancelTick(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TICK) WidgetRenderer.renderAll(context)
    }

    companion object {
        const val ACTION_TICK = "com.drwael.app.WIDGET_TICK"

        private fun tickPi(c: Context): PendingIntent {
            val i = Intent(c, PrayerWidget::class.java).apply { action = ACTION_TICK }
            return PendingIntent.getBroadcast(c, 9001, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        /** تحديث الويدجت عند موعد الصلاة القادمة ليتغير التمييز والعدّاد */
        fun scheduleTick(c: Context, atMs: Long) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            try {
                am.setAndAllowWhileIdle(AlarmManager.RTC, atMs, tickPi(c))
            } catch (e: Exception) {
                // تجاهل
            }
        }

        fun cancelTick(c: Context) {
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(tickPi(c))
        }

        fun enqueueOnce(c: Context) {
            val req = OneTimeWorkRequestBuilder<WidgetWorker>()
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(c).enqueueUniqueWork(Cfg.WIDGET_WORK_ONCE, ExistingWorkPolicy.REPLACE, req)
        }

        /** يعيد الرسم من الكاش فورًا ثم يجلب بيانات جديدة */
        fun refreshAll(c: Context) {
            WidgetRenderer.renderAll(c)
            enqueueOnce(c)
        }
    }
}
