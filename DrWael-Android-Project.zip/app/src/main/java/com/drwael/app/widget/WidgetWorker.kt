package com.drwael.app.widget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.drwael.app.Store
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class WidgetWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val c = applicationContext
        try {
            WidgetData.refresh(c, Store.city(c))
            WidgetRenderer.renderAll(c)
            Result.success()
        } catch (e: Exception) {
            WidgetRenderer.renderAll(c)
            Result.retry()
        }
    }
}
