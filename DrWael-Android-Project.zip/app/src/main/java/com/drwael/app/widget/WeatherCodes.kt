package com.drwael.app.widget

/** رموز الطقس — منقولة من WC في index.html */
object WeatherCodes {
    private val map: Map<Int, Pair<String, String>> = mapOf(
        0 to ("صافي" to "Clear"),
        1 to ("غالبًا صافي" to "Mostly clear"),
        2 to ("غائم جزئيًا" to "Partly cloudy"),
        3 to ("غائم" to "Overcast"),
        45 to ("ضباب" to "Fog"),
        48 to ("ضباب" to "Fog"),
        51 to ("رذاذ" to "Drizzle"),
        61 to ("مطر خفيف" to "Light rain"),
        63 to ("مطر" to "Rain"),
        65 to ("مطر غزير" to "Heavy rain"),
        80 to ("زخات" to "Showers"),
        95 to ("عاصفة رعدية" to "Thunderstorm")
    )

    fun text(code: Int, ar: Boolean): String = map[code]?.let { if (ar) it.first else it.second } ?: "—"
}
