package com.drwael.app.widget

/** المدن — منقولة من CITIES في index.html (الاسم الإنجليزي هو المفتاح) */
data class City(val key: String, val ar: String, val en: String, val lat: Double, val lon: Double)

object Cities {
    val all = listOf(
        City("Mansoura", "المنصورة", "Mansoura", 31.04, 31.38),
        City("Cairo", "القاهرة", "Cairo", 30.04, 31.24),
        City("Alexandria", "الإسكندرية", "Alexandria", 31.2, 29.92),
        City("Giza", "الجيزة", "Giza", 30.01, 31.21),
        City("Tanta", "طنطا", "Tanta", 30.79, 31.0),
        City("Zagazig", "الزقازيق", "Zagazig", 30.59, 31.5),
        City("Damietta", "دمياط", "Damietta", 31.42, 31.81),
        City("Assiut", "أسيوط", "Assiut", 27.18, 31.18),
        City("Luxor", "الأقصر", "Luxor", 25.69, 32.64),
        City("Aswan", "أسوان", "Aswan", 24.09, 32.9)
    )

    fun byKey(key: String?): City = all.firstOrNull { it.key == key } ?: all.first()
}
