package com.drwael.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import java.io.File

/** حفظ الملفات (PDF وغيرها) في مجلد التنزيلات */
object FileSaver {
    private fun cleanName(n: String): String {
        val x = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trim('.')
        return if (x.isBlank()) "file" else x.take(120)
    }

    fun save(c: Context, name: String, mime: String, b64: String): Boolean {
        return try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val fn = cleanName(name)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val v = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fn)
                    put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val r = c.contentResolver
                val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
                r.openOutputStream(uri)?.use { it.write(bytes) } ?: return false
                v.clear()
                v.put(MediaStore.Downloads.IS_PENDING, 0)
                r.update(uri, v, null, null)
                true
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                dir.mkdirs()
                var f = File(dir, fn)
                var k = 1
                val dot = fn.lastIndexOf('.')
                val base = if (dot > 0) fn.substring(0, dot) else fn
                val ext = if (dot > 0) fn.substring(dot) else ""
                while (f.exists()) { f = File(dir, "$base ($k)$ext"); k++ }
                f.writeBytes(bytes)
                MediaScannerConnection.scanFile(c, arrayOf(f.absolutePath), arrayOf(mime), null)
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
