package com.drwael.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject

/** تخزين محلي: مشفّر للجلسة، وعادي للإعدادات */
object Store {
    data class Session(val uid: String, val rt: String, val key: String, val pid: String)

    fun plain(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("dw_plain", Context.MODE_PRIVATE)

    @Synchronized
    fun secure(c: Context): SharedPreferences {
        val app = c.applicationContext
        fun create(): SharedPreferences {
            val mk = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                app, "dw_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            create()
        } catch (e: Exception) {
            // مفتاح تالف (نادر): نمسح ونعيد الإنشاء مرة واحدة
            try {
                app.deleteSharedPreferences("dw_secure")
                create()
            } catch (e2: Exception) {
                app.getSharedPreferences("dw_secure_fallback", Context.MODE_PRIVATE)
            }
        }
    }

    // ---------- الجلسة ----------
    fun saveSession(c: Context, s: Session) {
        secure(c).edit()
            .putString("uid", s.uid).putString("rt", s.rt)
            .putString("key", s.key).putString("pid", s.pid).apply()
        val p = plain(c)
        if (p.getLong("last_notif_at", 0L) == 0L) {
            p.edit().putLong("last_notif_at", System.currentTimeMillis()).apply()
        }
    }

    fun session(c: Context): Session? {
        val p = secure(c)
        val uid = p.getString("uid", null) ?: return null
        val rt = p.getString("rt", null) ?: return null
        val key = p.getString("key", null) ?: return null
        val pid = p.getString("pid", null) ?: return null
        if (uid.isBlank() || rt.isBlank() || key.isBlank() || pid.isBlank()) return null
        return Session(uid, rt, key, pid)
    }

    fun updateRefreshToken(c: Context, rt: String) {
        secure(c).edit().putString("rt", rt).apply()
    }

    fun clearSession(c: Context) {
        secure(c).edit().clear().apply()
        plain(c).edit().remove("last_notif_at").apply()
    }

    // ---------- إعدادات الويدجت ----------
    fun city(c: Context): String = plain(c).getString("city", "Mansoura") ?: "Mansoura"
    fun widgetTheme(c: Context): String = plain(c).getString("wt", "navy") ?: "navy"
    fun savePrefs(c: Context, city: String, wt: String) {
        plain(c).edit().putString("city", city).putString("wt", wt).apply()
    }

    // ---------- الإشعارات ----------
    /** يحوّل الثواني إلى مللي ثانية إن لزم */
    fun normAt(v: Long): Long = if (v in 1..99_999_999_999L) v * 1000 else v

    fun lastNotifAt(c: Context): Long = plain(c).getLong("last_notif_at", 0L)
    fun setLastNotifAt(c: Context, v: Long) {
        plain(c).edit().putLong("last_notif_at", v).apply()
    }

    // ---------- التذكيرات ----------
    @Synchronized
    fun reminders(c: Context): JSONObject =
        try { JSONObject(plain(c).getString("reminders", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    @Synchronized
    fun putReminder(c: Context, rid: String, title: String, body: String, at: Long) {
        val j = reminders(c)
        j.put(rid, JSONObject().put("t", title).put("b", body).put("at", at))
        plain(c).edit().putString("reminders", j.toString()).apply()
    }

    @Synchronized
    fun removeReminder(c: Context, rid: String) {
        val j = reminders(c)
        j.remove(rid)
        plain(c).edit().putString("reminders", j.toString()).apply()
    }

    // ---------- التذكير اليومي ----------
    fun saveDaily(c: Context, on: Boolean, h: Int, m: Int, title: String, body: String) {
        plain(c).edit()
            .putBoolean("daily_on", on).putInt("daily_h", h).putInt("daily_m", m)
            .putString("daily_t", title).putString("daily_b", body).apply()
    }
}
