package com.drwael.app.widget

import android.graphics.Color.argb

/** ألوان ثيمات الويدجت — منقولة حرفيًا من THEMES في index.html */
data class WTheme(val h1: Int, val h2: Int, val ga: Int, val gb: Int, val gc: Int, val gold: Int)

object WidgetThemes {
    private val all: Map<String, WTheme> = mapOf(
        "navy" to WTheme(argb(255, 178, 33, 39), argb(255, 58, 10, 14), argb(191, 255, 96, 80), argb(166, 255, 170, 140), argb(128, 255, 170, 70), argb(255, 245, 168, 58)),
        "dark" to WTheme(argb(255, 27, 31, 58), argb(255, 7, 8, 15), argb(115, 84, 120, 255), argb(89, 236, 100, 190), argb(76, 255, 170, 70), argb(255, 245, 168, 58)),
        "aurora" to WTheme(argb(255, 27, 18, 80), argb(255, 5, 3, 15), argb(217, 110, 70, 255), argb(153, 30, 200, 140), argb(128, 70, 120, 255), argb(255, 124, 240, 180)),
        "sunset" to WTheme(argb(255, 74, 29, 92), argb(255, 26, 10, 46), argb(204, 255, 120, 80), argb(166, 255, 70, 140), argb(153, 255, 190, 70), argb(255, 255, 179, 71)),
        "emerald" to WTheme(argb(255, 15, 74, 60), argb(255, 3, 26, 21), argb(191, 40, 200, 150), argb(140, 90, 230, 120), argb(115, 255, 220, 90), argb(255, 94, 224, 166)),
        "rose" to WTheme(argb(255, 122, 20, 32), argb(255, 42, 6, 11), argb(204, 255, 80, 90), argb(153, 255, 140, 120), argb(128, 255, 200, 120), argb(255, 255, 138, 128)),
        "mono" to WTheme(argb(255, 42, 42, 42), argb(255, 5, 5, 5), argb(76, 255, 255, 255), argb(76, 180, 180, 180), argb(51, 255, 255, 255), argb(255, 236, 236, 236)),
        "ocean" to WTheme(argb(255, 10, 61, 98), argb(255, 4, 26, 43), argb(204, 0, 180, 216), argb(140, 72, 202, 228), argb(102, 144, 224, 239), argb(255, 72, 202, 228)),
        "forest" to WTheme(argb(255, 20, 83, 45), argb(255, 5, 46, 22), argb(178, 34, 197, 94), argb(128, 132, 204, 22), argb(89, 250, 204, 21), argb(255, 134, 239, 172)),
        "sand" to WTheme(argb(255, 124, 90, 58), argb(255, 46, 31, 18), argb(178, 251, 191, 36), argb(140, 251, 146, 60), argb(102, 255, 237, 213), argb(255, 251, 191, 36)),
        "violet" to WTheme(argb(255, 59, 7, 100), argb(255, 18, 3, 31), argb(204, 168, 85, 247), argb(153, 236, 72, 153), argb(128, 99, 102, 241), argb(255, 216, 180, 254)),
        "cherry" to WTheme(argb(255, 131, 24, 67), argb(255, 42, 10, 26), argb(204, 244, 63, 94), argb(153, 251, 113, 133), argb(115, 253, 164, 175), argb(255, 253, 164, 175)),
        "lime" to WTheme(argb(255, 26, 46, 5), argb(255, 10, 20, 2), argb(191, 163, 230, 53), argb(140, 250, 204, 21), argb(115, 34, 197, 94), argb(255, 190, 242, 100)),
        "ice" to WTheme(argb(255, 12, 74, 110), argb(255, 8, 47, 73), argb(204, 125, 211, 252), argb(153, 165, 180, 252), argb(128, 255, 255, 255), argb(255, 186, 230, 253)),
        "gold" to WTheme(argb(255, 63, 42, 7), argb(255, 20, 13, 2), argb(204, 250, 204, 21), argb(166, 245, 158, 11), argb(89, 255, 255, 255), argb(255, 253, 224, 71)),
        "neon" to WTheme(argb(255, 11, 11, 43), argb(255, 3, 3, 15), argb(178, 0, 255, 200), argb(153, 255, 0, 200), argb(153, 80, 120, 255), argb(255, 34, 255, 208))
    )

    fun get(key: String?): WTheme = all[key ?: "navy"] ?: all.getValue("navy")
}
