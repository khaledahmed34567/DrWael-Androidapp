package com.drwael.app

/** ثوابت التطبيق */
object Cfg {
    /** أصل (origin) الصفحة داخل الـ WebView */
    val ORIGIN: String get() = "https://${BuildConfig.APP_HOST}"

    /** الصفحة تُحمَّل من assets/index.html عبر WebViewAssetLoader */
    val START_URL: String get() = "$ORIGIN/assets/index.html"

    /** مهلة السماح بعد الخروج من التطبيق قبل إعادة طلب البصمة */
    const val LOCK_GRACE_MS = 30_000L

    /** أسماء أيقونات التطبيق (نفس ICONS في الصفحة) */
    val ICONS = listOf("Default", "Glow", "Spray", "Red", "Dark", "Salmon", "Black")

    const val SYNC_WORK = "dw_sync"
    const val WIDGET_WORK_PERIODIC = "dw_widget_periodic"
    const val WIDGET_WORK_ONCE = "dw_widget_once"
}
