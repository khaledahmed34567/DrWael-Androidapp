package com.drwael.app

import androidx.lifecycle.lifecycleScope
import com.drwael.app.widget.PrayerWidget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * الجسر بين الصفحة والتطبيق. الصفحة تستدعي DWNative.postMessage(JSON) وتستقبل الرد في DWNative.onmessage.
 * كل رسالة: {a: الإجراء, id: رقم, ...بيانات} والرد: {id, ok, ...}
 */
class Bridge(private val act: MainActivity) {

    fun handle(raw: String, reply: (String) -> Unit) {
        val m = try { JSONObject(raw) } catch (e: Exception) { return }
        val id = m.optInt("id", 0)
        val a = m.optString("a")

        fun send(ok: Boolean, build: (JSONObject.() -> Unit)? = null) {
            val j = JSONObject().put("id", id).put("ok", ok)
            build?.invoke(j)
            reply(j.toString())
        }

        when (a) {
            "ver" -> send(true) { put("v", BuildConfig.VERSION_NAME) }

            "auth" -> act.requestBiometric(m.optString("why")) { ok -> send(ok) }

            "google" -> {
                act.skipLock = true
                act.lifecycleScope.launch {
                    when (val r = GoogleAuth.signIn(act)) {
                        is GoogleAuth.Result.Ok -> send(true) { put("token", r.idToken) }
                        is GoogleAuth.Result.Fail -> {
                            when (r.code) {
                                "cancel" -> Unit
                                "no_account" -> act.showGoogleError(r)
                                else -> act.showGoogleError(r)
                            }
                            send(false) { put("err", r.code) }
                        }
                    }
                }
            }

            "session" -> {
                val uid = m.optString("uid"); val rt = m.optString("rt")
                val key = m.optString("key"); val pid = m.optString("pid")
                if (uid.isBlank() || rt.isBlank() || key.isBlank() || pid.isBlank()) {
                    send(false)
                } else {
                    Store.saveSession(act, Store.Session(uid, rt, key, pid))
                    SyncWorker.schedule(act)
                    send(true)
                }
            }

            "logout" -> {
                Store.clearSession(act)
                SyncWorker.cancel(act)
                act.lifecycleScope.launch { GoogleAuth.signOut(act.applicationContext) }
                send(true)
            }

            "save" -> {
                val name = m.optString("name", "file")
                val mime = m.optString("mime", "application/octet-stream")
                val b64 = m.optString("b64", "")
                act.lifecycleScope.launch {
                    val ok = withContext(Dispatchers.IO) { FileSaver.save(act, name, mime, b64) }
                    send(ok)
                }
            }

            "notify" -> {
                val t = m.optString("t"); val b = m.optString("b")
                val at = Store.normAt(m.optLong("at", 0L))
                val last = Store.lastNotifAt(act)
                if (at == 0L) {
                    Notifs.show(act, Notifs.nextId(), t, b, Notifs.CH_STUDY)
                } else if (at > last) {
                    Notifs.show(act, (at % Int.MAX_VALUE).toInt(), t, b, Notifs.CH_GENERAL)
                    Store.setLastNotifAt(act, at)
                }
                send(true)
            }

            "daily" -> {
                Alarms.daily(
                    act, m.optBoolean("on", false), m.optInt("h", 20), m.optInt("m", 0),
                    m.optString("title"), m.optString("body")
                )
                send(true)
            }

            "remind" -> {
                Alarms.remind(act, m.optString("rid"), m.optString("title"), m.optString("body"), m.optLong("at", 0L))
                send(true)
            }

            "unremind" -> {
                Alarms.unremind(act, m.optString("rid"))
                send(true)
            }

            "update" -> { Updater.check(act, true); send(true) }

            "icon" -> send(IconSwitcher.set(act, m.optString("name")))

            "prefs" -> {
                val city = m.optString("city", "Mansoura").ifBlank { "Mansoura" }
                val wt = m.optString("wt", "navy").ifBlank { "navy" }
                Store.savePrefs(act, city, wt)
                PrayerWidget.refreshAll(act)
                send(true)
            }

            else -> send(false) { put("err", "unknown") }
        }
    }
}
