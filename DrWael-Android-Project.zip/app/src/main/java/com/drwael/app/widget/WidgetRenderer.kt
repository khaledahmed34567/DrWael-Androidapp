package com.drwael.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.widget.RemoteViews
import com.drwael.app.MainActivity
import com.drwael.app.R
import com.drwael.app.Store
import java.util.Calendar
import java.util.Locale

/** يرسم الويدجت كاملًا كصورة بخط الصفحة (AJ) وبنفس ثيماتها */
object WidgetRenderer {
    private val ORDER = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
    private var tfReg: Typeface? = null
    private var tfBold: Typeface? = null

    private fun fonts(c: Context) {
        if (tfReg != null) return
        tfReg = try { Typeface.createFromAsset(c.assets, "fonts/aj_400.ttf") } catch (e: Exception) { Typeface.DEFAULT }
        tfBold = try { Typeface.createFromAsset(c.assets, "fonts/aj_700.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
    }

    private fun pName(c: Context, k: String): String = c.getString(
        when (k) {
            "Fajr" -> R.string.p_fajr
            "Dhuhr" -> R.string.p_dhuhr
            "Asr" -> R.string.p_asr
            "Maghrib" -> R.string.p_maghrib
            else -> R.string.p_isha
        }
    )

    private fun mins(t: String): Int {
        val p = t.take(5).split(":")
        return p[0].toInt() * 60 + p[1].toInt()
    }

    private fun ms(t: String, dayOffset: Int): Long {
        val m = mins(t)
        return Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, dayOffset)
            set(Calendar.HOUR_OF_DAY, m / 60); set(Calendar.MINUTE, m % 60)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    private data class Ev(val key: String, val ms: Long)

    /** الصلاة القادمة، الوقت المتبقي، ونسبة التقدم بين الصلاتين */
    data class Next(val key: String, val inMin: Int, val atMs: Long, val progress: Float)

    fun next(s: Snap): Next? {
        return try {
            val t = s.timings
            val ev = ArrayList<Ev>()
            ev.add(Ev("Isha", ms(t["Isha"]!!, -1)))
            for (k in ORDER) ev.add(Ev(k, ms(t[k]!!, 0)))
            ev.add(Ev("Fajr", ms(t["Fajr"]!!, 1)))
            val now = System.currentTimeMillis()
            val nx = ev.firstOrNull { it.ms > now } ?: return null
            val pv = ev[maxOf(0, ev.indexOf(nx) - 1)].ms
            val prog = ((now - pv).toFloat() / (nx.ms - pv).coerceAtLeast(1)).coerceIn(0f, 1f)
            Next(nx.key, ((nx.ms - now + 59_999) / 60_000).toInt(), nx.ms, prog)
        } catch (e: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------ الخلفية

    private fun background(cv: Canvas, w: Int, h: Int, u: Float, th: WTheme) {
        val r = 24f * u
        cv.clipPath(Path().apply { addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, Path.Direction.CW) })
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), th.h1, th.h2, Shader.TileMode.CLAMP)
        cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        fun glow(cx: Float, cy: Float, rad: Float, col: Int) {
            val g = Paint(Paint.ANTI_ALIAS_FLAG)
            val t = Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))
            g.shader = RadialGradient(cx, cy, rad, col, t, Shader.TileMode.CLAMP)
            cv.drawCircle(cx, cy, rad, g)
        }
        val big = maxOf(w, h).toFloat()
        glow(w * 0.10f, h * 0.02f, big * 0.55f, th.ga)
        glow(w * 0.96f, h * 0.18f, big * 0.42f, th.gb)
        glow(w * 0.72f, h * 1.08f, big * 0.50f, th.gc)
        val b = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 1.2f * u; color = Color.argb(46, 255, 255, 255)
        }
        cv.drawRoundRect(RectF(1f, 1f, w - 1f, h - 1f), r, r, b)
    }

    // ------------------------------------------------------------------ أيقونات الطقس

    private fun drawWx(cv: Canvas, code: Int, cx: Float, cy: Float, r: Float, white: Int, accent: Int) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeWidth = r * 0.16f
        }
        fun sun(x: Float, y: Float, rr: Float) {
            fill.color = accent
            cv.drawCircle(x, y, rr * 0.5f, fill)
            line.color = accent
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val c1 = Math.cos(a).toFloat(); val s1 = Math.sin(a).toFloat()
                cv.drawLine(x + c1 * rr * 0.72f, y + s1 * rr * 0.72f, x + c1 * rr * 0.98f, y + s1 * rr * 0.98f, line)
            }
        }
        fun cloud(x: Float, y: Float, rr: Float) {
            fill.color = white
            cv.drawCircle(x - rr * 0.35f, y + rr * 0.1f, rr * 0.38f, fill)
            cv.drawCircle(x + rr * 0.08f, y - rr * 0.12f, rr * 0.5f, fill)
            cv.drawCircle(x + rr * 0.5f, y + rr * 0.12f, rr * 0.36f, fill)
            cv.drawRoundRect(RectF(x - rr * 0.72f, y + rr * 0.1f, x + rr * 0.86f, y + rr * 0.48f), rr * 0.2f, rr * 0.2f, fill)
        }
        when (code) {
            0, 1 -> sun(cx, cy, r)
            2 -> { sun(cx + r * 0.3f, cy - r * 0.3f, r * 0.7f); cloud(cx - r * 0.1f, cy + r * 0.15f, r * 0.8f) }
            45, 48 -> {
                line.color = white
                for (i in -1..1) cv.drawLine(cx - r * 0.8f, cy + i * r * 0.4f, cx + r * 0.8f, cy + i * r * 0.4f, line)
            }
            51, 61, 63, 65, 80 -> {
                cloud(cx, cy - r * 0.2f, r * 0.9f)
                line.color = accent
                for (i in -1..1) cv.drawLine(cx + i * r * 0.4f, cy + r * 0.55f, cx + i * r * 0.4f - r * 0.12f, cy + r * 0.9f, line)
            }
            95 -> {
                cloud(cx, cy - r * 0.2f, r * 0.9f)
                fill.color = accent
                val p = Path().apply {
                    moveTo(cx + r * 0.1f, cy + r * 0.3f); lineTo(cx - r * 0.2f, cy + r * 0.7f)
                    lineTo(cx, cy + r * 0.7f); lineTo(cx - r * 0.1f, cy + r * 1.05f)
                    lineTo(cx + r * 0.25f, cy + r * 0.55f); lineTo(cx + r * 0.05f, cy + r * 0.55f); close()
                }
                cv.drawPath(p, fill)
            }
            else -> cloud(cx, cy, r)
        }
    }

    // ------------------------------------------------------------------ الرسم

    private fun draw(
        c: Context, w: Int, h: Int, u: Float, th: WTheme, city: City, snap: Snap?, ar: Boolean
    ): Bitmap {
        fonts(c)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        background(cv, w, h, u, th)
        cv.scale(u, u)

        val W = w / u
        val H = h / u
        val compact = H < 140f
        val P = if (compact) 10f else 13f
        val white = Color.WHITE
        val gold = th.gold
        val dark = Color.rgb(26, 18, 0)

        fun paint(size: Float, color: Int, bold: Boolean = false): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; this.color = color; typeface = if (bold) tfBold else tfReg
        }
        // نص ملتصق ببداية الاتجاه (يمين في العربي) أو نهايته
        fun startText(s: String, off: Float, y: Float, p: Paint) {
            p.textAlign = if (ar) Paint.Align.RIGHT else Paint.Align.LEFT
            cv.drawText(s, if (ar) W - off else off, y, p)
        }
        fun endText(s: String, off: Float, y: Float, p: Paint) {
            p.textAlign = if (ar) Paint.Align.LEFT else Paint.Align.RIGHT
            cv.drawText(s, if (ar) off else W - off, y, p)
        }
        fun phys(offStart: Float, width: Float): Float = if (ar) W - offStart - width else offStart

        // ----- الشريط العلوي: شعار + المدينة + الطقس
        val topY = P + 12f
        val badge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold }
        val bx = phys(P, 20f) + 10f
        cv.drawCircle(bx, P + 8f, 10f, badge)
        val wp = paint(12f, dark, true).apply { textAlign = Paint.Align.CENTER }
        cv.drawText("W", bx, P + 12.5f, wp)
        startText(if (ar) city.ar else city.en, P + 26f, topY - 1f, paint(13.5f, gold, true))

        if (snap != null && snap.temp != null) {
            var off = P
            val tp = paint(13.5f, white, true)
            val tt = "${snap.temp}°"
            val tw = tp.measureText(tt)
            endText(tt, off, topY - 1f, tp)
            off += tw + 6f
            if (snap.code != null && W > 250f) {
                val dp = paint(11f, Color.argb(210, 255, 255, 255))
                val ds = WeatherCodes.text(snap.code, ar)
                endText(ds, off, topY - 1f, dp)
                off += dp.measureText(ds) + 8f
            }
            if (snap.code != null) {
                val ix = if (ar) off + 8f else W - off - 8f
                drawWx(cv, snap.code, ix, P + 8f, 8.5f, white, gold)
            }
        }

        if (snap == null || snap.timings.isEmpty()) {
            val lp = paint(15f, white, true).apply { textAlign = Paint.Align.CENTER }
            cv.drawText(c.getString(R.string.widget_loading), W / 2f, H / 2f + 6f, lp)
            return bmp
        }
        val nx = next(snap)

        // ----- الصلاة القادمة
        val nameY = if (compact) P + 44f else P + 58f
        if (!compact) {
            startText(c.getString(R.string.widget_next), P, P + 34f, paint(10.5f, Color.argb(170, 255, 255, 255)))
        }
        if (nx != null) {
            val np = paint(if (compact) 22f else 26f, white, true)
            val nm = pName(c, nx.key)
            startText(nm, P, nameY, np)
            val tp2 = paint(if (compact) 22f else 26f, gold, true)
            startText(snap.timings[nx.key] ?: "", P + np.measureText(nm) + 10f, nameY, tp2)

            // كبسولة الوقت المتبقي
            val hh = nx.inMin / 60
            val mm = nx.inMin % 60
            val left = c.getString(R.string.widget_in) + " " +
                (if (hh > 0) "$hh${c.getString(R.string.widget_h)} " else "") + "$mm${c.getString(R.string.widget_m)}"
            val cp = paint(12.5f, white, true)
            val cw = cp.measureText(left) + 20f
            val chh = 26f
            val cy0 = nameY - 20f
            val left0 = if (ar) P else W - P - cw
            val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(46, 255, 255, 255) }
            cv.drawRoundRect(RectF(left0, cy0, left0 + cw, cy0 + chh), 13f, 13f, pill)
            cp.textAlign = Paint.Align.CENTER
            cv.drawText(left, left0 + cw / 2f, cy0 + 17.5f, cp)

            // شريط التقدم
            if (!compact) {
                val by = nameY + 10f
                val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(46, 255, 255, 255) }
                val bw = W - 2 * P
                cv.drawRoundRect(RectF(P, by, P + bw, by + 4f), 2f, 2f, track)
                val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = gold }
                val fw = bw * nx.progress
                val fx = if (ar) P + bw - fw else P
                cv.drawRoundRect(RectF(fx, by, fx + fw, by + 4f), 2f, 2f, fillP)
            }
        }

        // ----- بلاطات الصلوات الخمس
        val footer = H >= 175f
        val tileH = if (compact) 34f else 42f
        val tileBottom = H - P - (if (footer) 18f else 0f)
        val tileTop = tileBottom - tileH
        val gap = 6f
        val tileW = (W - 2 * P - gap * 4) / 5f
        val now = System.currentTimeMillis()
        for (i in 0..4) {
            val k = ORDER[i]
            val tm = snap.timings[k] ?: "--:--"
            val hot = nx?.key == k
            val passed = try { ms(tm, 0) < now } catch (e: Exception) { false }
            val left0 = phys(P + i * (tileW + gap), tileW)
            val rect = RectF(left0, tileTop, left0 + tileW, tileBottom)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            if (hot) {
                bg.shader = LinearGradient(rect.left, rect.top, rect.left, rect.bottom, gold, gold, Shader.TileMode.CLAMP)
            } else {
                bg.color = Color.argb(if (passed) 22 else 40, 255, 255, 255)
            }
            cv.drawRoundRect(rect, 12f, 12f, bg)
            val a = if (passed && !hot) 130 else 255
            val np = paint(if (compact) 10.5f else 11f, if (hot) dark else Color.argb(a, 255, 255, 255)).apply { textAlign = Paint.Align.CENTER }
            val tp = paint(if (compact) 12.5f else 13.5f, if (hot) dark else Color.argb(a, 255, 255, 255), true).apply { textAlign = Paint.Align.CENTER }
            val mid = rect.centerX()
            cv.drawText(pName(c, k), mid, rect.top + tileH * 0.40f, np)
            cv.drawText(tm, mid, rect.top + tileH * 0.80f, tp)
        }

        // ----- التذييل: التاريخ الهجري والعظمى/الصغرى
        if (footer) {
            val fp = paint(10.5f, Color.argb(190, 255, 255, 255))
            startText(snap.hijri, P, H - P - 3f, fp)
            if (snap.hi != null && snap.lo != null) {
                endText(
                    "${c.getString(R.string.widget_high)} ${snap.hi}° / ${c.getString(R.string.widget_low)} ${snap.lo}°",
                    P, H - P - 3f, fp
                )
            }
        }
        return bmp
    }

    // ------------------------------------------------------------------ الواجهة العامة

    fun renderAll(c: Context) {
        val mgr = AppWidgetManager.getInstance(c)
        val ids = mgr.getAppWidgetIds(ComponentName(c, PrayerWidget::class.java))
        if (ids.isEmpty()) return
        for (id in ids) render(c, mgr, id)
    }

    fun render(c: Context, mgr: AppWidgetManager, id: Int) {
        val density = c.resources.displayMetrics.density
        val opts = mgr.getAppWidgetOptions(id)
        val wDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250).coerceAtLeast(150)
        val hDp = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 120).coerceAtLeast(100)
        var u = density
        var w = (wDp * u).toInt()
        var h = (hDp * u).toInt()
        val maxPx = 1_200_000
        if (w * h > maxPx) {
            val k = Math.sqrt(maxPx.toDouble() / (w * h)).toFloat()
            u *= k; w = (wDp * u).toInt(); h = (hDp * u).toInt()
        }
        val cityKey = Store.city(c)
        val city = Cities.byKey(cityKey)
        val th = WidgetThemes.get(Store.widgetTheme(c))
        val ar = Locale.getDefault().language == "ar"
        val snap = WidgetData.cached(c, cityKey)

        val bmp = draw(c, w, h, u, th, city, snap, ar)
        val rv = RemoteViews(c.packageName, R.layout.widget_prayer)
        rv.setImageViewBitmap(R.id.w_img, bmp)

        val nx = snap?.let { next(it) }
        val desc = (if (ar) city.ar else city.en) +
            (if (nx != null && snap != null) " — " + pName(c, nx.key) + " " + (snap.timings[nx.key] ?: "") else "")
        rv.setContentDescription(R.id.w_img, desc)

        val open = Intent(c, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        rv.setOnClickPendingIntent(
            R.id.w_root,
            PendingIntent.getActivity(c, 4242, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        )
        mgr.updateAppWidget(id, rv)

        // تحديث العدّاد كل 5 دقائق وعند موعد الصلاة القادمة
        val now = System.currentTimeMillis()
        val tick = if (nx != null) minOf(nx.atMs + 1500, now + 5 * 60_000L) else now + 30 * 60_000L
        PrayerWidget.scheduleTick(c, tick)
    }
}
