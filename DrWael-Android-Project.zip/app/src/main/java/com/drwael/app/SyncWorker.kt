package com.drwael.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * مزامنة الإشعارات في الخلفية: يجدد توكن الجلسة المحفوظة ثم يقرأ مجموعة notifs
 * (نفس الاستعلام الذي تستخدمه الصفحة: to IN ["all", uid]) ويعرض الجديد كإشعار نظام.
 */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val c = applicationContext
        val s = Store.session(c) ?: return@withContext Result.success()
        try {
            val idToken = refresh(c, s) ?: return@withContext Result.retry()
            val list = fetchNotifs(s, idToken)
            val last = Store.lastNotifAt(c)
            var newest = last
            val fresh = list.filter { it.at > last && it.ch != "site" }.sortedBy { it.at }
            for (n in fresh.takeLast(5)) {
                Notifs.show(c, (n.at % Int.MAX_VALUE).toInt(), n.title, n.body, Notifs.CH_GENERAL)
            }
            for (n in list) if (n.at > newest) newest = n.at
            if (newest > last) Store.setLastNotifAt(c, newest)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private data class N(val title: String, val body: String, val at: Long, val ch: String)

    private fun conn(url: String, method: String, referer: String): HttpURLConnection {
        val u = (URL(url).openConnection() as HttpURLConnection)
        u.requestMethod = method
        u.connectTimeout = 15000
        u.readTimeout = 20000
        u.setRequestProperty("Referer", referer)
        u.setRequestProperty("X-Android-Package", BuildConfig.APPLICATION_ID)
        return u
    }

    private fun refresh(c: Context, s: Store.Session): String? {
        val referer = "https://${BuildConfig.APP_HOST}/"
        val u = conn("https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(s.key, "UTF-8"), "POST", referer)
        u.doOutput = true
        u.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        val body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(s.rt, "UTF-8")
        u.outputStream.use { it.write(body.toByteArray()) }
        if (u.responseCode !in 200..299) {
            // 400 = توكن منتهي/ملغي: نتوقف عن المحاولة حتى يسجل المستخدم من جديد
            if (u.responseCode == 400) Store.clearSession(c)
            return null
        }
        val j = JSONObject(u.inputStream.bufferedReader().use { it.readText() })
        val newRt = j.optString("refresh_token", "")
        if (newRt.isNotBlank() && newRt != s.rt) Store.updateRefreshToken(c, newRt)
        return j.optString("id_token", "").ifBlank { null }
    }

    private fun fetchNotifs(s: Store.Session, idToken: String): List<N> {
        val referer = "https://${BuildConfig.APP_HOST}/"
        val u = conn(
            "https://firestore.googleapis.com/v1/projects/${s.pid}/databases/(default)/documents:runQuery",
            "POST", referer
        )
        u.doOutput = true
        u.setRequestProperty("Authorization", "Bearer $idToken")
        u.setRequestProperty("Content-Type", "application/json")
        val vals = JSONArray()
            .put(JSONObject().put("stringValue", "all"))
            .put(JSONObject().put("stringValue", s.uid))
        val q = JSONObject().put(
            "structuredQuery", JSONObject()
                .put("from", JSONArray().put(JSONObject().put("collectionId", "notifs")))
                .put(
                    "where", JSONObject().put(
                        "fieldFilter", JSONObject()
                            .put("field", JSONObject().put("fieldPath", "to"))
                            .put("op", "IN")
                            .put("value", JSONObject().put("arrayValue", JSONObject().put("values", vals)))
                    )
                )
                .put("limit", 30)
        )
        u.outputStream.use { it.write(q.toString().toByteArray()) }
        if (u.responseCode !in 200..299) return emptyList()
        val arr = JSONArray(u.inputStream.bufferedReader().use { it.readText() })
        val out = ArrayList<N>()
        for (i in 0 until arr.length()) {
            val f = arr.optJSONObject(i)?.optJSONObject("document")?.optJSONObject("fields") ?: continue
            val title = f.optJSONObject("title")?.optString("stringValue", "") ?: ""
            val body = f.optJSONObject("body")?.optString("stringValue", "") ?: ""
            val ch = f.optJSONObject("ch")?.optString("stringValue", "both") ?: "both"
            val atO = f.optJSONObject("at")
            val at = when {
                atO == null -> 0L
                atO.has("integerValue") -> atO.optString("integerValue", "0").toLongOrNull() ?: 0L
                atO.has("doubleValue") -> atO.optDouble("doubleValue", 0.0).toLong()
                else -> 0L
            }
            if (title.isNotBlank() || body.isNotBlank()) out.add(N(title, body, Store.normAt(at), ch))
        }
        return out
    }

    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(Cfg.SYNC_WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(c: Context) {
            WorkManager.getInstance(c).cancelUniqueWork(Cfg.SYNC_WORK)
        }
    }
}
