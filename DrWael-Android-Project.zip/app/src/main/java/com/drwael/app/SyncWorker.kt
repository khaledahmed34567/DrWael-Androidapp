package com.drwael.app

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit

/**
 * مزامنة الخلفية الدورية:
 * 1) إشعارات notifs (to IN ["all", uid])
 * 2) رصد المحاضرات الجديدة (lectures) للدورات المشترك بها وإطلاق إشعار محلي
 * 3) رصد مواعيد تسليم المهام (tasks.dueAt) قبل 24 ساعة وقبل 1 ساعة بدون تكرار
 * 4) فحص التحديثات عن بُعد (settings/app -> androidVer)
 */
class SyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val c = applicationContext
        val s = Store.session(c) ?: return@withContext Result.success()
        try {
            val idToken = refresh(c, s) ?: return@withContext Result.retry()
            val ar = Store.appLang(c) != "en"

            // 1. Notifs collection
            val list = fetchNotifs(s, idToken)
            val last = Store.lastNotifAt(c)
            var newest = last
            val fresh = list.filter { it.at > last && it.ch != "site" }.sortedBy { it.at }
            for (n in fresh.takeLast(5)) {
                Notifs.show(c, (n.at % Int.MAX_VALUE).toInt(), n.title, n.body, Notifs.CH_GENERAL)
            }
            for (n in list) if (n.at > newest) newest = n.at
            if (newest > last) Store.setLastNotifAt(c, newest)

            // 2. Remote updates check (settings/app)
            checkRemoteAppUpdate(c, s, idToken, ar)

            // 3. Enrolled courses -> new lectures + task dueAt alerts
            val needLec = Store.alertLec(c)
            val needDue = Store.alertDue(c)
            if (needLec || needDue) {
                val courseNames = fetchAccessibleCourseNames(s, idToken, ar)
                val courseIds = courseNames.keys.toList()
                if (courseIds.isNotEmpty()) {
                    if (needLec) checkNewLectures(c, s, idToken, courseIds, courseNames, ar)
                    if (needDue) checkTaskDeadlines(c, s, idToken, courseIds, ar)
                }
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private data class N(val title: String, val body: String, val at: Long, val ch: String)

    private fun conn(url: String, method: String, referer: String): HttpURLConnection {
        val u = (URL(url).openConnection() as HttpURLConnection)
        u.requestMethod = method
        u.connectTimeout = 15000
        u.readTimeout = 20000
        u.setRequestProperty("Referer", referer)
        u.setRequestProperty("X-Android-Package", BuildConfig.APPLICATION_ID)
        return u
    }

    private fun refresh(c: Context, s: Store.Session): String? {
        val referer = "https://${BuildConfig.APP_HOST}/"
        val u = conn("https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(s.key, "UTF-8"), "POST", referer)
        u.doOutput = true
        u.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        val body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(s.rt, "UTF-8")
        u.outputStream.use { it.write(body.toByteArray()) }
        if (u.responseCode !in 200..299) {
            if (u.responseCode == 400) Store.clearSession(c)
            return null
        }
        val j = JSONObject(u.inputStream.bufferedReader().use { it.readText() })
        val newRt = j.optString("refresh_token", "")
        if (newRt.isNotBlank() && newRt != s.rt) Store.updateRefreshToken(c, newRt)
        return j.optString("id_token", "").ifBlank { null }
    }

    private fun getDoc(s: Store.Session, idToken: String, path: String): JSONObject? {
        val referer = "https://${BuildConfig.APP_HOST}/"
        val u = conn("https://firestore.googleapis.com/v1/projects/${s.pid}/databases/(default)/documents/$path", "GET", referer)
        u.setRequestProperty("Authorization", "Bearer $idToken")
        if (u.responseCode !in 200..299) return null
        return JSONObject(u.inputStream.bufferedReader().use { it.readText() })
    }

    private fun listCollection(s: Store.Session, idToken: String, col: String, pageSize: Int = 200): List<Pair<String, JSONObject>> {
        val referer = "https://${BuildConfig.APP_HOST}/"
        val u = conn("https://firestore.googleapis.com/v1/projects/${s.pid}/databases/(default)/documents/$col?pageSize=$pageSize", "GET", referer)
        u.setRequestProperty("Authorization", "Bearer $idToken")
        if (u.responseCode !in 200..299) return emptyList()
        val j = JSONObject(u.inputStream.bufferedReader().use { it.readText() })
        val docs = j.optJSONArray("documents") ?: return emptyList()
        val out = ArrayList<Pair<String, JSONObject>>()
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val name = d.optString("name", "").substringAfterLast('/')
            val fields = d.optJSONObject("fields") ?: continue
            if (name.isNotBlank()) out.add(name to fields)
        }
        return out
    }

    private fun runQuery(s: Store.Session, idToken: String, sq: JSONObject): List<Pair<String, JSONObject>> {
        val referer = "https://${BuildConfig.APP_HOST}/"
        val u = conn("https://firestore.googleapis.com/v1/projects/${s.pid}/databases/(default)/documents:runQuery", "POST", referer)
        u.doOutput = true
        u.setRequestProperty("Authorization", "Bearer $idToken")
        u.setRequestProperty("Content-Type", "application/json")
        u.outputStream.use { it.write(JSONObject().put("structuredQuery", sq).toString().toByteArray()) }
        if (u.responseCode !in 200..299) return emptyList()
        val arr = JSONArray(u.inputStream.bufferedReader().use { it.readText() })
        val out = ArrayList<Pair<String, JSONObject>>()
        for (i in 0 until arr.length()) {
            val d = arr.optJSONObject(i)?.optJSONObject("document") ?: continue
            val id = d.optString("name", "").substringAfterLast('/')
            val fields = d.optJSONObject("fields") ?: continue
            if (id.isNotBlank()) out.add(id to fields)
        }
        return out
    }

    private fun strField(f: JSONObject, key: String): String =
        f.optJSONObject(key)?.optString("stringValue", "") ?: ""

    private fun intField(f: JSONObject, key: String): Long {
        val o = f.optJSONObject(key) ?: return 0L
        return when {
            o.has("integerValue") -> o.optString("integerValue", "0").toLongOrNull() ?: 0L
            o.has("doubleValue") -> o.optDouble("doubleValue", 0.0).toLong()
            else -> 0L
        }
    }

    private fun boolField(f: JSONObject, key: String): Boolean =
        f.optJSONObject(key)?.optBoolean("booleanValue", false) ?: false

    private fun parseTsMillis(o: JSONObject?): Long {
        if (o == null) return 0L
        if (o.has("integerValue")) {
            val v = o.optString("integerValue", "0").toLongOrNull() ?: 0L
            return Store.normAt(v)
        }
        if (o.has("doubleValue")) {
            val v = o.optDouble("doubleValue", 0.0).toLong()
            return Store.normAt(v)
        }
        val ts = when {
            o.has("timestampValue") -> o.optString("timestampValue", "")
            o.has("stringValue") -> o.optString("stringValue", "")
            else -> ""
        }.trim()
        if (ts.isBlank()) return 0L
        ts.toLongOrNull()?.let { return Store.normAt(it) }
        val clean = ts.replace(Regex("\\.\\d+Z$"), "Z")
        for (pat in listOf("yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ssZ", "yyyy-MM-dd'T'HH:mm")) {
            try {
                val sdf = SimpleDateFormat(pat, Locale.US)
                if (pat.endsWith("'Z'")) sdf.timeZone = TimeZone.getTimeZone("UTC")
                val d = sdf.parse(clean)
                if (d != null) return d.time
            } catch (_: Exception) {}
        }
        return 0L
    }

    private fun cmpVer(a: String, b: String): Int {
        val pa = a.trimStart('v', 'V').split('.').map { it.replace(Regex("\\D.*"), "").toIntOrNull() ?: 0 }
        val pb = b.trimStart('v', 'V').split('.').map { it.replace(Regex("\\D.*"), "").toIntOrNull() ?: 0 }
        for (i in 0 until maxOf(pa.size, pb.size)) {
            val d = (pa.getOrElse(i) { 0 }) - (pb.getOrElse(i) { 0 })
            if (d != 0) return d
        }
        return 0
    }

    private fun checkRemoteAppUpdate(c: Context, s: Store.Session, idToken: String, ar: Boolean) {
        val doc = getDoc(s, idToken, "settings/app")?.optJSONObject("fields") ?: return
        val ver = strField(doc, "androidVer").trim().trimStart('v', 'V')
        if (ver.isBlank() || cmpVer(ver, BuildConfig.VERSION_NAME) <= 0) return
        if (Store.notifiedRemoteVer(c) == ver) return
        Store.setNotifiedRemoteVer(c, ver)
        val notes = strField(doc, "updateNotes").trim()
        val title = if (ar) "تحديث جديد متاح ($ver)" else "Update available ($ver)"
        val body = notes.ifBlank { if (ar) "افتح التطبيق لتثبيت الإصدار الأحدث." else "Open the app to install the latest version." }
        Notifs.show(c, 880_001, title, body, Notifs.CH_GENERAL)
    }

    private fun fetchNotifs(s: Store.Session, idToken: String): List<N> {
        val vals = JSONArray()
            .put(JSONObject().put("stringValue", "all"))
            .put(JSONObject().put("stringValue", s.uid))
        val sq = JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", "notifs")))
            .put(
                "where", JSONObject().put(
                    "fieldFilter", JSONObject()
                        .put("field", JSONObject().put("fieldPath", "to"))
                        .put("op", "IN")
                        .put("value", JSONObject().put("arrayValue", JSONObject().put("values", vals)))
                )
            )
            .put("limit", 30)
        val out = ArrayList<N>()
        for ((_, f) in runQuery(s, idToken, sq)) {
            val title = strField(f, "title")
            val body = strField(f, "body")
            val ch = strField(f, "ch").ifBlank { "both" }
            val at = Store.normAt(intField(f, "at"))
            if (title.isNotBlank() || body.isNotBlank()) out.add(N(title, body, at, ch))
        }
        return out
    }

    private fun fetchAccessibleCourseNames(s: Store.Session, idToken: String, ar: Boolean): Map<String, String> {
        val userFields = getDoc(s, idToken, "users/${s.uid}")?.optJSONObject("fields") ?: return emptyMap()
        val yr = intField(userFields, "year")
        val tm = intField(userFields, "term")
        val role = strField(userFields, "role")
        val extraSet = HashSet<String>()
        val extraArr = userFields.optJSONObject("extra")?.optJSONObject("arrayValue")?.optJSONArray("values")
        if (extraArr != null) {
            for (i in 0 until extraArr.length()) {
                val id = extraArr.optJSONObject(i)?.optString("stringValue", "") ?: ""
                if (id.isNotBlank()) extraSet.add(id)
            }
        }

        val subsSet = HashSet<String>()
        val subsQ = JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", "subs")))
            .put(
                "where", JSONObject().put(
                    "fieldFilter", JSONObject()
                        .put("field", JSONObject().put("fieldPath", "uid"))
                        .put("op", "EQUAL")
                        .put("value", JSONObject().put("stringValue", s.uid))
                )
            )
        for ((_, f) in runQuery(s, idToken, subsQ)) {
            val cid = strField(f, "courseId")
            if (cid.isNotBlank()) subsSet.add(cid)
        }

        val out = LinkedHashMap<String, String>()
        for ((cid, f) in listCollection(s, idToken, "courses")) {
            val matchYrTm = intField(f, "year") == yr && intField(f, "term") == tm
            val price = intField(f, "price")
            val accessible = (matchYrTm || extraSet.contains(cid)) && (price <= 0L || subsSet.contains(cid) || role == "admin")
            if (accessible) {
                val tAr = strField(f, "title")
                val tEn = strField(f, "titleEn")
                out[cid] = if (ar) tAr.ifBlank { tEn } else tEn.ifBlank { tAr }
            }
        }
        return out
    }

    private fun queryByCourseIds(s: Store.Session, idToken: String, col: String, courseIds: List<String>): List<Pair<String, JSONObject>> {
        val out = ArrayList<Pair<String, JSONObject>>()
        for (chunk in courseIds.chunked(10)) {
            val vals = JSONArray()
            chunk.forEach { vals.put(JSONObject().put("stringValue", it)) }
            val sq = JSONObject()
                .put("from", JSONArray().put(JSONObject().put("collectionId", col)))
                .put(
                    "where", JSONObject().put(
                        "fieldFilter", JSONObject()
                            .put("field", JSONObject().put("fieldPath", "courseId"))
                            .put("op", "IN")
                            .put("value", JSONObject().put("arrayValue", JSONObject().put("values", vals)))
                    )
                )
            out.addAll(runQuery(s, idToken, sq))
        }
        return out
    }

    private fun checkNewLectures(
        c: Context, s: Store.Session, idToken: String,
        courseIds: List<String>, courseNames: Map<String, String>, ar: Boolean
    ) {
        val lecs = queryByCourseIds(s, idToken, "lectures", courseIds)
        val seen = Store.seenLectures(c)
        if (!Store.isSeenLecturesInit(c)) {
            lecs.forEach { seen.add(it.first) }
            Store.saveSeenLectures(c, seen)
            return
        }
        var added = false
        for ((lid, f) in lecs) {
            if (seen.contains(lid)) continue
            seen.add(lid)
            added = true
            val cid = strField(f, "courseId")
            val lAr = strField(f, "title")
            val lEn = strField(f, "titleEn")
            val lName = if (ar) lAr.ifBlank { lEn } else lEn.ifBlank { lAr }
            val cName = courseNames[cid] ?: ""
            val title = if (ar) "محاضرة جديدة متاحة" else "New lecture available"
            val body = if (cName.isNotBlank()) "$lName — $cName" else lName
            Notifs.show(c, lid.hashCode(), title, body, Notifs.CH_GENERAL)
        }
        if (added) Store.saveSeenLectures(c, seen)
    }

    private fun checkTaskDeadlines(
        c: Context, s: Store.Session, idToken: String, courseIds: List<String>, ar: Boolean
    ) {
        val progQ = JSONObject()
            .put("from", JSONArray().put(JSONObject().put("collectionId", "progress")))
            .put(
                "where", JSONObject().put(
                    "fieldFilter", JSONObject()
                        .put("field", JSONObject().put("fieldPath", "uid"))
                        .put("op", "EQUAL")
                        .put("value", JSONObject().put("stringValue", s.uid))
                )
            )
        val doneSet = HashSet<String>()
        for ((_, f) in runQuery(s, idToken, progQ)) {
            if (boolField(f, "done")) {
                val tid = strField(f, "taskId")
                if (tid.isNotBlank()) doneSet.add(tid)
            }
        }

        val tasks = queryByCourseIds(s, idToken, "tasks", courseIds)
        val now = System.currentTimeMillis()
        for ((tid, f) in tasks) {
            if (doneSet.contains(tid)) continue
            val dueObj = f.optJSONObject("dueAt")
                ?: f.optJSONObject("deadline")
                ?: f.optJSONObject("dueDate")
                ?: f.optJSONObject("due")
            val dm = parseTsMillis(dueObj)
            if (dm <= now) continue
            val diff = dm - now
            val stage = when {
                diff <= 3_600_000L -> "1h"
                diff <= 86_400_000L -> "24h"
                else -> ""
            }
            if (stage.isBlank()) continue
            val key = "due:$tid:$stage:$dm"
            if (Store.hasDueKey(c, key)) continue
            Store.markDueKey(c, key)
            val tAr = strField(f, "title")
            val tEn = strField(f, "titleEn")
            val tName = if (ar) tAr.ifBlank { tEn } else tEn.ifBlank { tAr }
            val title = when {
                stage == "1h" && ar -> "موعد تسليم عاجل (أقل من ساعة)"
                stage == "1h" -> "Urgent deadline (< 1h)"
                ar -> "تذكير بموعد التسليم (خلال 24 ساعة)"
                else -> "Deadline reminder (24h)"
            }
            val dueStr = SimpleDateFormat("MMM d, HH:mm", if (ar) Locale("ar", "EG") else Locale.ENGLISH)
                .format(java.util.Date(dm))
            Notifs.show(c, key.hashCode(), title, "$tName — $dueStr", Notifs.CH_REMINDERS)
        }
    }

    companion object {
        fun schedule(c: Context) {
            val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(Cfg.SYNC_WORK, ExistingPeriodicWorkPolicy.KEEP, req)
        }

        fun cancel(c: Context) {
            WorkManager.getInstance(c).cancelUniqueWork(Cfg.SYNC_WORK)
        }
    }
}
