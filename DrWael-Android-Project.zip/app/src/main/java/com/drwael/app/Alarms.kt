package com.drwael.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/** جدولة التذكيرات (امتحانات ومواعيد) والتذكير اليومي بالمذاكرة */
object Alarms {
    private const val KIND = "kind"
    private const val K_REMIND = "remind"
    private const val K_DAILY = "daily"
    private const val DAILY_CODE = 777_001

    private fun am(c: Context) = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    private fun remindPi(c: Context, rid: String, title: String?, body: String?): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).apply {
            action = "com.drwael.app.REMIND"
            putExtra(KIND, K_REMIND); putExtra("rid", rid)
            if (title != null) putExtra("t", title)
            if (body != null) putExtra("b", body)
        }
        return PendingIntent.getBroadcast(
            c, rid.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun dailyPi(c: Context): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java).apply {
            action = "com.drwael.app.DAILY"
            putExtra(KIND, K_DAILY)
        }
        return PendingIntent.getBroadcast(
            c, DAILY_CODE, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun set(c: Context, pi: PendingIntent, at: Long) {
        val m = am(c)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !m.canScheduleExactAlarms()) {
                m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                m.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            m.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    // ---------- تذكيرات ----------
    fun remind(c: Context, rid: String, title: String, body: String, at: Long) {
        if (rid.isBlank()) return
        Store.putReminder(c, rid, title, body, at)
        if (at > System.currentTimeMillis()) set(c, remindPi(c, rid, title, body), at)
    }

    fun unremind(c: Context, rid: String) {
        if (rid.isBlank()) return
        Store.removeReminder(c, rid)
        val pi = remindPi(c, rid, null, null)
        am(c).cancel(pi)
        pi.cancel()
    }

    fun cancelDueAlarms(c: Context) {
        val keys = Store.reminders(c).keys().asSequence().toList()
        for (rid in keys) {
            if (rid.startsWith("due:")) unremind(c, rid)
        }
    }

    // ---------- يومي ----------
    fun daily(c: Context, on: Boolean, h: Int, m: Int, title: String, body: String) {
        Store.saveDaily(c, on, h, m, title, body)
        am(c).cancel(dailyPi(c))
        if (on) scheduleNextDaily(c)
    }

    private fun scheduleNextDaily(c: Context) {
        val p = Store.plain(c)
        if (!p.getBoolean("daily_on", false)) return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, p.getInt("daily_h", 20))
            set(Calendar.MINUTE, p.getInt("daily_m", 0))
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 1000) add(Calendar.DAY_OF_YEAR, 1)
        }
        set(c, dailyPi(c), cal.timeInMillis)
    }

    /** بعد إعادة التشغيل أو تغيير الوقت */
    fun rescheduleAll(c: Context) {
        val j = Store.reminders(c)
        val now = System.currentTimeMillis()
        val keys = j.keys().asSequence().toList()
        for (rid in keys) {
            val o = j.optJSONObject(rid) ?: continue
            val at = o.optLong("at", 0L)
            if (at > now) {
                set(c, remindPi(c, rid, o.optString("t"), o.optString("b")), at)
            } else {
                Store.removeReminder(c, rid)
            }
        }
        scheduleNextDaily(c)
    }

    internal fun onFire(c: Context, i: Intent) {
        when (i.getStringExtra(KIND)) {
            K_REMIND -> {
                val rid = i.getStringExtra("rid") ?: return
                val o = Store.reminders(c).optJSONObject(rid)
                val t = i.getStringExtra("t") ?: o?.optString("t") ?: c.getString(R.string.app_name)
                val b = i.getStringExtra("b") ?: o?.optString("b") ?: ""
                Notifs.show(c, rid.hashCode(), t, b, Notifs.CH_REMINDERS)
                Store.removeReminder(c, rid)
            }
            K_DAILY -> {
                val p = Store.plain(c)
                if (p.getBoolean("daily_on", false)) {
                    Notifs.show(
                        c, DAILY_CODE,
                        p.getString("daily_t", c.getString(R.string.app_name)) ?: c.getString(R.string.app_name),
                        p.getString("daily_b", "") ?: "",
                        Notifs.CH_STUDY
                    )
                    scheduleNextDaily(c)
                }
            }
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Alarms.onFire(context, intent)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Alarms.rescheduleAll(context)
        com.drwael.app.widget.PrayerWidget.refreshAll(context)
        if (Store.session(context) != null) SyncWorker.schedule(context)
    }
}
