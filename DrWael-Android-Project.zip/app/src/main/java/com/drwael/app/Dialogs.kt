package com.drwael.app

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.content.res.ColorStateList

/** نوافذ منبثقة بتصميم التطبيق (بدل نوافذ النظام والـ WebView الافتراضية) */
object Dialogs {
    private const val RED = 0xFFB22127.toInt()
    private const val INK = 0xFF101426.toInt()
    private const val MUTE = 0xFF4A4F68.toInt()
    private var reg: Typeface? = null
    private var bold: Typeface? = null

    private fun fonts(a: Activity) {
        if (reg != null) return
        reg = try { Typeface.createFromAsset(a.assets, "fonts/aj_400.ttf") } catch (e: Exception) { Typeface.DEFAULT }
        bold = try { Typeface.createFromAsset(a.assets, "fonts/aj_700.ttf") } catch (e: Exception) { Typeface.DEFAULT_BOLD }
    }

    private fun dp(a: Activity, v: Int) = (v * a.resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Float) = GradientDrawable().apply { setColor(color); cornerRadius = r }

    private fun base(a: Activity, cancelable: Boolean): Pair<Dialog, LinearLayout> {
        fonts(a)
        val d = Dialog(a)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(a, 22), dp(a, 20), dp(a, 22), dp(a, 16))
            background = rounded(Color.WHITE, dp(a, 26).toFloat())
        }
        d.setContentView(card)
        d.setCancelable(cancelable)
        d.setCanceledOnTouchOutside(cancelable)
        d.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            // نفس منع التصوير للنوافذ العائمة
            setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
            val w = minOf((a.resources.displayMetrics.widthPixels * 0.9f).toInt(), dp(a, 420))
            setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.6f)
            setGravity(Gravity.CENTER)
        }
        return d to card
    }

    private fun accent(a: Activity): View = View(a).apply {
        background = rounded(RED, dp(a, 3).toFloat())
        layoutParams = LinearLayout.LayoutParams(dp(a, 42), dp(a, 5)).apply { bottomMargin = dp(a, 14) }
    }

    private fun button(a: Activity, text: String, primary: Boolean): TextView = TextView(a).apply {
        this.text = text
        typeface = bold
        textSize = 15f
        gravity = Gravity.CENTER
        setTextColor(if (primary) Color.WHITE else MUTE)
        background = rounded(if (primary) RED else 0xFFF1F1F4.toInt(), dp(a, 14).toFloat())
        setPadding(dp(a, 20), dp(a, 11), dp(a, 20), dp(a, 11))
        minWidth = dp(a, 96)
    }

    fun show(
        a: Activity, title: String, message: String?, pos: String, neg: String? = null,
        cancelable: Boolean = true, extra: View? = null, selectable: Boolean = false,
        onPos: (() -> Unit)? = null, onNeg: (() -> Unit)? = null, onCancel: (() -> Unit)? = null
    ): Dialog {
        val (d, card) = base(a, cancelable)
        card.addView(accent(a))
        card.addView(TextView(a).apply {
            text = title; typeface = bold; textSize = 19f; setTextColor(INK)
            textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        })
        if (!message.isNullOrBlank()) {
            card.addView(TextView(a).apply {
                text = message; typeface = reg; textSize = 14.5f; setTextColor(MUTE)
                setLineSpacing(0f, 1.25f)
                textAlignment = View.TEXT_ALIGNMENT_VIEW_START
                setTextIsSelectable(selectable)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(a, 10) }
            })
        }
        if (extra != null) {
            (extra.layoutParams as? LinearLayout.LayoutParams ?: LinearLayout.LayoutParams(-1, -2)).also {
                it.topMargin = dp(a, 12); extra.layoutParams = it
            }
            card.addView(extra)
        }
        val row = LinearLayout(a).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(a, 20) }
        }
        if (neg != null) {
            val nb = button(a, neg, false)
            nb.setOnClickListener { d.dismiss(); onNeg?.invoke() }
            row.addView(nb, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(a, 10) })
        }
        val pb = button(a, pos, true)
        pb.setOnClickListener { d.dismiss(); onPos?.invoke() }
        row.addView(pb)
        card.addView(row)
        d.setOnCancelListener { onCancel?.invoke() }
        if (!a.isFinishing) d.show()
        return d
    }

    /** نافذة تقدّم (تنزيل التحديث) — تُرجع النافذة ودالة تحديث النسبة */
    fun progress(a: Activity, title: String, message: String): Pair<Dialog, (Int) -> Unit> {
        val (d, card) = base(a, false)
        card.addView(accent(a))
        card.addView(TextView(a).apply { text = title; typeface = bold; textSize = 19f; setTextColor(INK) })
        card.addView(TextView(a).apply {
            text = message; typeface = reg; textSize = 14.5f; setTextColor(MUTE)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(a, 8); bottomMargin = dp(a, 14) }
        })
        val bar = ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; isIndeterminate = true
            progressTintList = ColorStateList.valueOf(RED)
            indeterminateTintList = ColorStateList.valueOf(RED)
        }
        card.addView(bar, LinearLayout.LayoutParams(-1, dp(a, 8)))
        if (!a.isFinishing) d.show()
        return d to { p: Int -> a.runOnUiThread { bar.isIndeterminate = false; bar.progress = p } }
    }
}
