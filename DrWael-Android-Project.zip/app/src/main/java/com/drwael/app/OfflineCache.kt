package com.drwael.app

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/**
 * مخزن مكتبات الصفحة (Firebase و KaTeX و pdf.js) داخل التطبيق: يُحفظ أول ما يتحمّل ويُقدَّم من الجهاز،
 * فيفتح التطبيق وتعمل التحميلات (PDF/فيديو) حتى بدون إنترنت.
 */
object OfflineCache {
    private val running = AtomicBoolean(false)
    private const val KATEX = "https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/"
    private val PREFETCH = listOf(
        "https://www.gstatic.com/firebasejs/10.12.2/firebase-app-compat.js",
        "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth-compat.js",
        "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore-compat.js",
        KATEX + "katex.min.css",
        KATEX + "katex.min.js",
        KATEX + "contrib/mhchem.min.js",
        KATEX + "contrib/auto-render.min.js",
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js",
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js"
    )

    fun allowed(u: Uri): Boolean {
        if (u.scheme != "https") return false
        val h = u.host ?: return false
        val p = u.path ?: ""
        return (h == "www.gstatic.com" && p.startsWith("/firebasejs/")) ||
            (h == "cdnjs.cloudflare.com" && p.startsWith("/ajax/libs/")) ||
            (h == "cdn.jsdelivr.net" && p.startsWith("/npm/pdfjs-dist"))
    }

    private fun dir(c: Context): File = File(c.filesDir, "libcache").apply { mkdirs() }

    private fun name(url: String): String =
        MessageDigest.getInstance("SHA-1").digest(url.toByteArray()).joinToString("") { "%02x".format(it) }

    private fun mimeFor(url: String, header: String?): String {
        val h = header?.substringBefore(';')?.trim()
        if (!h.isNullOrBlank() && h != "application/octet-stream") return h
        val path = url.substringBefore('?')
        return when {
            path.endsWith(".js") || path.endsWith(".mjs") -> "application/javascript"
            path.endsWith(".css") -> "text/css"
            path.endsWith(".woff2") -> "font/woff2"
            path.endsWith(".json") -> "application/json"
            path.endsWith(".bcmap") -> "application/octet-stream"
            else -> "application/octet-stream"
        }
    }

    private fun cached(c: Context, url: String): Boolean {
        val n = name(url)
        return File(dir(c), n).exists() && File(dir(c), "$n.m").exists()
    }

    private fun fetch(c: Context, url: String): Boolean {
        return try {
            val con = URL(url).openConnection() as HttpURLConnection
            con.connectTimeout = 12000
            con.readTimeout = 20000
            con.instanceFollowRedirects = true
            if (con.responseCode != 200) return false
            val n = name(url)
            val tmp = File(dir(c), "$n.tmp")
            con.inputStream.use { ins -> tmp.outputStream().use { ins.copyTo(it) } }
            val f = File(dir(c), n)
            f.delete()
            if (!tmp.renameTo(f)) return false
            File(dir(c), "$n.m").writeText(mimeFor(url, con.contentType))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** يقدّم المورد من المخزن (أو يجلبه ويحفظه). يرجع null لو غير متاح ليكمل WebView بالشبكة. */
    fun serve(c: Context, req: WebResourceRequest): WebResourceResponse? {
        if (req.method != "GET" || !allowed(req.url)) return null
        val url = req.url.toString().substringBefore('#')
        if (!cached(c, url) && !fetch(c, url)) return null
        val n = name(url)
        val mime = File(dir(c), "$n.m").readText()
        val enc = if (mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json")) "UTF-8" else null
        return WebResourceResponse(
            mime, enc, 200, "OK",
            mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "public, max-age=31536000"),
            FileInputStream(File(dir(c), n))
        )
    }

    /** يحمّل المكتبات مسبقًا في الخلفية (مرة كل 12 ساعة إن نجح) */
    fun prefetch(c: Context) {
        val app = c.applicationContext
        val p = Store.plain(app)
        if (System.currentTimeMillis() - p.getLong("lib_prefetch_at", 0L) < 12 * 3600_000L) return
        if (!running.compareAndSet(false, true)) return
        Thread {
            try {
                var ok = true
                for (u in PREFETCH) if (!cached(app, u) && !fetch(app, u)) ok = false
                // خطوط KaTeX المذكورة في ملف الـ CSS
                val css = File(dir(app), name(KATEX + "katex.min.css"))
                if (css.exists()) {
                    val fonts = Regex("url\\((fonts/[^)]+?\\.woff2)\\)").findAll(css.readText()).map { it.groupValues[1] }.toSet()
                    for (f in fonts) {
                        val u = KATEX + f
                        if (!cached(app, u) && !fetch(app, u)) ok = false
                    }
                }
                if (ok) p.edit().putLong("lib_prefetch_at", System.currentTimeMillis()).apply()
            } catch (e: Exception) {
                // تجاهل
            } finally {
                running.set(false)
            }
        }.start()
    }
}
