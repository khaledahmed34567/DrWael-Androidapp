package com.drwael.app

import android.app.Activity
import android.content.Context
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

/** تسجيل الدخول بجوجل داخل التطبيق (Credential Manager) — يرجع idToken للصفحة */
object GoogleAuth {
    sealed class Result {
        data class Ok(val idToken: String) : Result()
        data class Fail(val code: String) : Result()
    }

    /** Web client ID: من BuildConfig إن وُجد، وإلا من google-services.json (default_web_client_id) */
    fun webClientId(c: Context): String {
        if (BuildConfig.WEB_CLIENT_ID.isNotBlank()) return BuildConfig.WEB_CLIENT_ID
        val id = c.resources.getIdentifier("default_web_client_id", "string", c.packageName)
        return if (id != 0) c.getString(id) else ""
    }

    suspend fun signIn(act: Activity): Result {
        val cid = webClientId(act)
        if (cid.isBlank()) return Result.Fail("no_client")
        return try {
            val cm = CredentialManager.create(act)
            val opt = GetSignInWithGoogleOption.Builder(cid).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
            val res = cm.getCredential(act, req)
            val cred = res.credential
            if (cred is CustomCredential &&
                cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                val g = GoogleIdTokenCredential.createFrom(cred.data)
                Result.Ok(g.idToken)
            } else {
                Result.Fail("bad_credential")
            }
        } catch (e: GetCredentialCancellationException) {
            Result.Fail("cancel")
        } catch (e: NoCredentialException) {
            Result.Fail("no_account")
        } catch (e: GetCredentialException) {
            Result.Fail("error:" + (e.type))
        } catch (e: Exception) {
            Result.Fail("exception")
        }
    }

    suspend fun signOut(c: Context) {
        try {
            CredentialManager.create(c).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            // تجاهل
        }
    }
}
