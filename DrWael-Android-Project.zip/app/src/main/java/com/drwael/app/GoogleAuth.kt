package com.drwael.app

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** تسجيل الدخول بجوجل داخل التطبيق (Credential Manager) — يرجع idToken للصفحة */
object GoogleAuth {
    sealed class Result {
        data class Ok(val idToken: String) : Result()
        data class Fail(val code: String, val detail: String = "", val clientId: String = "") : Result()
    }

    /** Web client ID المحلي: BuildConfig ثم web_client_id.xml ثم google-services.json */
    private fun localClientId(c: Context): String {
        if (BuildConfig.WEB_CLIENT_ID.isNotBlank()) return BuildConfig.WEB_CLIENT_ID
        val own = c.getString(R.string.web_client_id).trim()
        if (own.isNotEmpty()) return own
        val id = c.resources.getIdentifier("default_web_client_id", "string", c.packageName)
        return if (id != 0) c.getString(id).trim() else ""
    }

    /** يكتشف Web client ID تلقائيًا من إعدادات مشروع Firebase (لا يحتاج أي إعداد يدوي) */
    private fun discover(): String = try {
        val u = URL("https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key=" + BuildConfig.FIREBASE_API_KEY)
        val c = u.openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 12000
        c.readTimeout = 15000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Referer", "https://${BuildConfig.APP_HOST}/")
        val body = JSONObject().put("providerId", "google.com").put("continueUri", "https://${BuildConfig.APP_HOST}")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode in 200..299) {
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            Uri.parse(j.optString("authUri")).getQueryParameter("client_id") ?: ""
        } else ""
    } catch (e: Exception) {
        ""
    }

    suspend fun clientId(c: Context): String {
        val local = localClientId(c)
        if (local.isNotBlank()) return local
        val p = Store.plain(c)
        p.getString("web_cid", null)?.takeIf { it.isNotBlank() }?.let { return it }
        val found = withContext(Dispatchers.IO) { discover() }
        if (found.isNotBlank()) p.edit().putString("web_cid", found).apply()
        return found
    }

    /** بصمة SHA-1 الفعلية للتطبيق المثبّت (للتشخيص) */
    fun sha1(c: Context): String = try {
        val pm = c.packageManager
        val sigs = if (Build.VERSION.SDK_INT >= 28) {
            pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNING_CERTIFICATES).signingInfo?.apkContentsSigners
        } else {
            @Suppress("DEPRECATION")
            pm.getPackageInfo(c.packageName, PackageManager.GET_SIGNATURES).signatures
        }
        sigs?.firstOrNull()?.let { s ->
            MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString(":") { "%02X".format(it) }
        } ?: "?"
    } catch (e: Exception) {
        "?"
    }

    suspend fun signIn(act: Activity): Result {
        val cid = clientId(act)
        if (cid.isBlank()) return Result.Fail("no_client", "تعذّر الحصول على Web client ID. تأكد من تفعيل Google في Firebase Authentication.")
        return try {
            val cm = CredentialManager.create(act)
            val opt = GetSignInWithGoogleOption.Builder(cid).build()
            val req = GetCredentialRequest.Builder().addCredentialOption(opt).build()
            val res = cm.getCredential(act, req)
            val cred = res.credential
            if (cred is CustomCredential &&
                cred.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {
                Result.Ok(GoogleIdTokenCredential.createFrom(cred.data).idToken)
            } else {
                Result.Fail("bad_credential", cred.type, cid)
            }
        } catch (e: GetCredentialCancellationException) {
            Result.Fail("cancel", "", cid)
        } catch (e: NoCredentialException) {
            Result.Fail("no_account", e.message ?: "", cid)
        } catch (e: GetCredentialException) {
            Result.Fail("error", e.type + "\n" + (e.message ?: ""), cid)
        } catch (e: Exception) {
            Result.Fail("exception", e.javaClass.simpleName + ": " + (e.message ?: ""), cid)
        }
    }

    suspend fun signOut(c: Context) {
        try {
            CredentialManager.create(c).clearCredentialState(ClearCredentialStateRequest())
        } catch (e: Exception) {
            // تجاهل
        }
    }
}
