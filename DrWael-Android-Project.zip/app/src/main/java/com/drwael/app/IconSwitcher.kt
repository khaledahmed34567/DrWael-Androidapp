package com.drwael.app

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** تبديل أيقونة التطبيق عبر activity-alias (الأسماء نفس ICONS في الصفحة) */
object IconSwitcher {
    fun set(c: Context, name: String): Boolean {
        if (name !in Cfg.ICONS) return false
        val pm = c.packageManager
        fun cn(n: String) = ComponentName(c.packageName, "com.drwael.app.alias.$n")
        return try {
            // نفعّل الجديدة أولًا حتى لا تختفي الأيقونة لحظة
            pm.setComponentEnabledSetting(cn(name), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP)
            for (n in Cfg.ICONS) {
                if (n != name) {
                    pm.setComponentEnabledSetting(cn(n), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP)
                }
            }
            Store.plain(c).edit().putString("icon", name).apply()
            true
        } catch (e: Exception) {
            false
        }
    }
}
