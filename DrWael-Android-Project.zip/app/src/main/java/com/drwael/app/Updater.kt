package com.drwael.app

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.core.content.FileProvider
import androidx.core.content.pm.PackageInfoCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * التحديث من GitHub Releases: كل نشر جديد (Release) يظهر للمستخدم كنافذة تحديث برقم الإصدار،
 * يُنزَّل الـ APK ويُتحقق من توقيعه (نفس توقيع التطبيق المثبّت) ثم يُثبَّت.
 */
object Updater {
    private data class Info(val tag: String, val code: Int, val notes: String, val url: String, val force: Boolean)

    private var checking = false
    private var dialogShown = false
    private var pendingFile: File? = null
    private var lastCheck = 0L

    private fun fetchLatest(): Info? {
        val u = URL("https://api.github.com/repos/${BuildConfig.UPDATE_REPO}/releases/latest")
        val c = u.openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 15000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "DrWaelApp/" + BuildConfig.VERSION_NAME)
        if (c.responseCode != 200) return null
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val tag = j.optString("tag_name", "")
        val code = Regex("(\\d+)\\D*$").find(tag)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        val assets = j.optJSONArray("assets") ?: return null
        var url = ""
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk", true)) { url = a.optString("browser_download_url"); break }
        }
        if (url.isBlank()) return null
        var body = j.optString("body", "").trim()
        val force = body.contains("[force]", true)
        body = body.replace("[force]", "", true).trim().take(700)
        return Info(tag.trimStart('v', 'V'), code, body, url, force)
    }

    /** يفحص وجود إصدار أحدث. force=true يتجاوز الفاصل الزمني. */
    fun check(act: MainActivity, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (checking || dialogShown) return
        if (!force && now - lastCheck < 30 * 60_000L) return
        checking = true
        lastCheck = now
        act.lifecycleScope.launch {
            val info = withContext(Dispatchers.IO) { try { fetchLatest() } catch (e: Exception) { null } }
            checking = false
            if (info != null && info.code > BuildConfig.VERSION_CODE && !act.isFinishing) showOffer(act, info)
        }
    }

    private fun showOffer(act: MainActivity, i: Info) {
        dialogShown = true
        val msg = act.getString(R.string.update_msg, i.tag, BuildConfig.VERSION_NAME) +
            (if (i.notes.isNotBlank()) "\n\n" + i.notes else "")
        val b = AlertDialog.Builder(act)
            .setTitle(R.string.update_title)
            .setMessage(msg)
            .setCancelable(!i.force)
            .setPositiveButton(R.string.update_now, null)
            .setOnDismissListener { dialogShown = false }
        if (!i.force) b.setNegativeButton(R.string.update_later, null)
        val d = b.create()
        d.setCanceledOnTouchOutside(!i.force)
        d.show()
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            d.dismiss()
            download(act, i)
        }
    }

    private fun download(act: MainActivity, i: Info) {
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; isIndeterminate = true }
        val txt = TextView(act).apply { text = act.getString(R.string.update_downloading); gravity = Gravity.CENTER; setPadding(0, 0, 0, 24) }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 40, 56, 24)
            addView(txt); addView(bar)
        }
        val dlg = AlertDialog.Builder(act).setView(box).setCancelable(false).create()
        dlg.show()
        act.lifecycleScope.launch {
            val f = withContext(Dispatchers.IO) {
                try {
                    val dir = File(act.cacheDir, "updates").apply { mkdirs() }
                    dir.listFiles()?.forEach { it.delete() }
                    val out = File(dir, "DrWael-${i.tag}.apk")
                    val c = URL(i.url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = true
                    if (c.responseCode != 200) return@withContext null
                    val total = c.contentLengthLong
                    c.inputStream.use { ins ->
                        out.outputStream().use { os ->
                            val buf = ByteArray(32 * 1024)
                            var done = 0L
                            var last = 0
                            while (true) {
                                val n = ins.read(buf)
                                if (n <= 0) break
                                os.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val p = (done * 100 / total).toInt()
                                    if (p != last) { last = p; act.runOnUiThread { bar.isIndeterminate = false; bar.progress = p } }
                                }
                            }
                        }
                    }
                    out
                } catch (e: Exception) {
                    null
                }
            }
            dlg.dismiss()
            if (f == null || !verify(act, f)) {
                act.toast(R.string.update_failed)
                f?.delete()
                return@launch
            }
            install(act, f)
        }
    }

    private fun sigs(pm: PackageManager, pkgInfoFlagsArchivePath: String?, pkg: String): Set<String>? {
        return try {
            val info = if (pkgInfoFlagsArchivePath != null) {
                if (Build.VERSION.SDK_INT >= 28) pm.getPackageArchiveInfo(pkgInfoFlagsArchivePath, PackageManager.GET_SIGNING_CERTIFICATES)
                else @Suppress("DEPRECATION") pm.getPackageArchiveInfo(pkgInfoFlagsArchivePath, PackageManager.GET_SIGNATURES)
            } else {
                if (Build.VERSION.SDK_INT >= 28) pm.getPackageInfo(pkg, PackageManager.GET_SIGNING_CERTIFICATES)
                else @Suppress("DEPRECATION") pm.getPackageInfo(pkg, PackageManager.GET_SIGNATURES)
            } ?: return null
            val arr = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners
            else @Suppress("DEPRECATION") info.signatures
            arr?.map { s -> MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) } }?.toSet()
        } catch (e: Exception) {
            null
        }
    }

    /** نفس الحزمة + إصدار أحدث + نفس توقيع التطبيق المثبّت */
    private fun verify(act: MainActivity, f: File): Boolean {
        val pm = act.packageManager
        val arch = try {
            if (Build.VERSION.SDK_INT >= 28) pm.getPackageArchiveInfo(f.absolutePath, 0)
            else @Suppress("DEPRECATION") pm.getPackageArchiveInfo(f.absolutePath, 0)
        } catch (e: Exception) { null } ?: return false
        if (arch.packageName != act.packageName) return false
        if (PackageInfoCompat.getLongVersionCode(arch) <= BuildConfig.VERSION_CODE) return false
        val a = sigs(pm, f.absolutePath, act.packageName) ?: return false
        val b = sigs(pm, null, act.packageName) ?: return false
        return a.isNotEmpty() && a == b
    }

    private fun install(act: MainActivity, f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
            pendingFile = f
            act.toast(R.string.update_allow)
            act.skipLock = true
            try {
                act.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName))
                )
            } catch (e: Exception) {
                // تجاهل
            }
            return
        }
        launchInstaller(act, f)
    }

    private fun launchInstaller(act: MainActivity, f: File) {
        val uri = FileProvider.getUriForFile(act, act.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        act.skipLock = true
        try { act.startActivity(i) } catch (e: Exception) { act.toast(R.string.update_failed) }
    }

    /** بعد رجوع المستخدم من شاشة «السماح بتثبيت التطبيقات» */
    fun resumePending(act: MainActivity) {
        val f = pendingFile ?: return
        if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) return
        pendingFile = null
        if (f.exists()) launchInstaller(act, f)
    }
}
